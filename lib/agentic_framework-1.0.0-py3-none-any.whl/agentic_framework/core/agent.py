from agentic_framework.factory.agent_factory import AgentFactory
from agentic_adapters.core.base_agent import BaseAgent

class Agent(BaseAgent):
    def __init__(self, agent_config):
        print(f"inside agent init :::: {agent_config}")
        instance_type = agent_config['type']
        self.agent_instance = AgentFactory.get_instance(instance_type, agent_config)
        print(type(self.agent_instance))

    
    async def run(self, input: str, context=None) -> str:
        print(f"inside run ")
        return await self.agent_instance.run(input, context)

