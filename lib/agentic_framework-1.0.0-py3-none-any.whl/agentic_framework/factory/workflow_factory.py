import os
import importlib
from pathlib import Path

from agentic_adapters.core.base_workflow import BaseWorkflow
from agentic_framework.utils.common_utils import CommonUtils 

instances = {}
classes = {}

class WorkflowFactory:
    _instance = None  # Class variable to hold the single instance

    def __new__(cls):
        # If instance is not created yet, create it
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        config_path = os.path.join(os.path.dirname(Path(__file__).parent),'config','factory-config.yaml')
        self.factory_config  = CommonUtils.load_yaml(config_path)
        print(f'config_path {config_path}')
        print(f'{self.factory_config}')

    @staticmethod
    def get_instance(instance_type='', config_parameters=None) -> BaseWorkflow:
        print(f"\n\n\nInside Factory\n\n\n")
        ins_type = instance_type.lower()
        factory = WorkflowFactory()
        
        instance = factory.load_workflow(ins_type, config_parameters)
        instances[ins_type] = instance
        print(f'instance {instance}')  
        instances[ins_type] = instance
        return instance
    
    @staticmethod
    def find_instance(instance_type='', config_parameters=None) -> BaseWorkflow:
        print(f"Inside Factory")
        ins_type = instance_type.lower()
        factory = WorkflowFactory()
        if ins_type in instances:
            instance = instances[ins_type]
        else:
            instance = factory.load_workflow(ins_type, config_parameters)
            instances[ins_type] = instance
            print(f'instance {instance}')  
        
        return instance
    
    def load_workflow(self, instance_type, config_parameters):
        clazz_instance = None
        #for config in self.factory_config['tool']['generator']:
        for config in self.factory_config['workflow']:
            ins_type = config['type'].lower()
            if ins_type == instance_type:
                class_path = config['class']
                # Dynamically import the agent class
                if class_path in classes:
                    clazz = classes[class_path]    
                else :    
                    module_name, class_name = class_path.rsplit('.', 1)  # Split the class path into module and class
                    module = importlib.import_module(module_name)  # Import the module
                    clazz = getattr(module, class_name)  # Get the class from the module
                    classes[class_path] = clazz
                    print(f' class_name {class_name} config_parameters {config_parameters}')
                # Instantiate the workflow class with the specific configuration
                clazz_instance = clazz(config_parameters)
                #clazz_instance = clazz()
                return clazz_instance
            else:
                continue
        return clazz_instance


