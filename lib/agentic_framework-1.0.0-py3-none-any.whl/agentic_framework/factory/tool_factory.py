import os
import importlib
from pathlib import Path

from agentic_adapters.core.base_tool_generator import BaseToolGenerator
from agentic_framework.utils.common_utils import CommonUtils 

instances = {}

class ToolFactory:
    _instance = None  # Class variable to hold the single instance

    def __new__(cls):
        # If instance is not created yet, create it
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        
        config_path = os.path.join(os.path.dirname(Path(__file__).parent),'config','factory-config.yaml')
        self.factory_config  = CommonUtils.load_yaml(config_path)
        print(f'config_path {config_path}')
        print(f'{self.factory_config}')

    @staticmethod
    def get_instance(instance_type='', config_parameters=None) -> BaseToolGenerator:
        print(f"Inside Factory")
        
        ins_type = instance_type.lower()
        
        factory = ToolFactory()
        if ins_type in instances:
            instance = instances[ins_type]
        else:
            instance = factory.load_tool_generator(ins_type, config_parameters)
            instances[ins_type] = instance
            print(f'instance {instance}')  
        
        return instance
    
    def load_tool_generator(self, instance_type, config_parameters):
        clazz_instance = None
        for config in self.factory_config['tool']['generator']:
            ins_type = config['type'].lower()
            if ins_type == instance_type:
                class_path = config['class']
                # Dynamically import the publisher class
                module_name, class_name = class_path.rsplit('.', 1)  # Split the class path into module and class
                module = importlib.import_module(module_name)  # Import the module
                clazz = getattr(module, class_name)  # Get the class from the module
                print(f' class_name {class_name} config_parameters {config_parameters}')
                # Instantiate the publisher class with the specific configuration
                #clazz_instance = clazz(config_parameters)
                clazz_instance = clazz()
                return clazz_instance
            else:
                continue
        return clazz_instance


