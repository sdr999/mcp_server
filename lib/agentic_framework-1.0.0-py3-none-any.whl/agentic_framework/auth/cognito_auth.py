import base64
import requests
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend

# AWS Cognito configuration
REGION = "us-east-1"
USER_POOL_ID = "us-east-1_etV6oJuIn"
ISSUER = f"https://cognito-idp.{REGION}.amazonaws.com/{USER_POOL_ID}"
JWKS_URL = f"{ISSUER}/.well-known/jwks.json"
ALGORITHM = "RS256"

# Load JWKs and map by key ID (kid)
jwks = requests.get(JWKS_URL).json()
public_keys = {key["kid"]: key for key in jwks["keys"]}

def build_rsa_public_key(jwk):
    n = int.from_bytes(base64.urlsafe_b64decode(jwk["n"] + '=='), "big")
    e = int.from_bytes(base64.urlsafe_b64decode(jwk["e"] + '=='), "big")
    public_numbers = rsa.RSAPublicNumbers(e, n)
    return public_numbers.public_key(backend=default_backend())

def get_public_key(kid: str):
    if kid not in public_keys:
        raise HTTPException(status_code=401, detail="Invalid token header: unknown kid")
    return build_rsa_public_key(public_keys[kid])

security = HTTPBearer()

def validate_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header["kid"]
        public_key = get_public_key(kid)
        payload = jwt.decode(
            token,
            public_key,
            algorithms=[ALGORITHM],
            issuer=ISSUER,
        )
        return payload
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"JWT validation failed: {str(e)}",
        )
