import os

def validate_token(credentials: HTTPAuthorizationCredentials = Depends()):
    auth_type = os.getenv("AUTH_PROVIDER", "cognito")
    if auth_type == "cognito":
        from agentic_framework.auth.cognito_auth import validate_token as cognito_validate_token
        return cognito_validate_token(credentials)
    elif auth_type == "auth0":
        from agentic_adapters.adapter_auth0_auth.auth0_auth import validate_token as auth0_validate_token
        return auth0_validate_token(credentials)
    else:
        raise Exception("Unsupported auth provider configured.")
