from agentic_adapters.core.base_agent import BaseAgent
from agentic_adapters.utils.mcp_server_generator import generate_server_file, run_server, validate_tools
from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.models.lite_llm import LiteLlm
from google.adk.sessions import InMemorySessionService
from google.genai import types
from google.adk.tools.mcp_tool import MCPTool
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.tools.mcp_tool import SseConnectionParams
from contextlib import AsyncExitStack
import os
import json
import subprocess
from typing import Any
from typing import TypedDict, List, Dict
import subprocess
import sys
import importlib
import asyncio
from agentic_framework.utils import global_variables
from adk_extra_services.sessions import MongoSessionService
from langfuse import Langfuse
from openinference.instrumentation.google_adk import GoogleADKInstrumentor
from opentelemetry.propagate import inject


#Custom class that defines state of Agent
class AgentState(TypedDict):
    input: str
    history: list
    output: str

class CustomCallbackHandler():
    _after_model_func:str =None
    _before_model_func:str =None
    _after_tool_func:str =None
    _before_tool_func:str= None
    model_function=None
    tools_function=None

    def __init__(self,functions:Any=None):
        if functions is not None:
            self.model_function=functions["model"] 
            self.tools_function=functions["tools"] 
            self._before_model_func=self.model_function["before"] 
            self._after_model_func=self.model_function["after"]
        # self._before_tool_func=before_tool_func
        # self._after_tool_func=after_tool_func
    # Tool Start
    def before_tool_call(self,tool:Any,*args,**kwargs):
        print("before tool call executed:: :: :: ::")
        
        try:
            if self.tools_function is not None: 
                self._before_tool_func=self.tools_function[tool.name]["before"]
                if self._before_tool_func is not None:
                    exec(self._before_tool_func,{"self": self})
        except Exception as e:
            
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # Tool End
    def after_tool_call(self,tool:Any,*args,**kwargs):
        try:
            if self.tools_function is not None: 
                self._after_tool_func=self.tools_function[tool.name]["after"]
                if self._after_tool_func is not None:
                    exec(self._after_tool_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # LLM Start
    def before_model_call(self,*args,**kwargs):
        try:
            if self.model_function is not None: 
                if self._before_model_func is not None:
                    exec(self._before_model_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
 
    # LLM End
    def after_model_call(self,*args,**kwargs):
        try:
            if self.model_function is not None:
                if self._after_model_func is not None:
                    exec(self._after_model_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")



class GoogleADKAgent(BaseAgent):
    def __init__(self, config: dict):
        
        #Load config
        self.config = config
        self.langfuse_public_key=global_variables.env['LANGFUSE_PUBLIC_KEY']
        self.langfuse_secret_key=global_variables.env['LANGFUSE_SECRET_KEY']
        self.langfuse_host=global_variables.env['LANGFUSE_HOST']
        self.langfuse = Langfuse(
            secret_key=self.langfuse_secret_key,
            public_key=self.langfuse_public_key,
            host=self.langfuse_host
           )
        GoogleADKInstrumentor().instrument()
        
        functions=self.config["callback_functions"]
        print("functions:: :: ::",functions)
        self.mcp_servers=self.config["mcp_servers"]
        self.custom_callback_handler=CustomCallbackHandler(functions)
        self.load_model_properties()
        
        #Install required packages
        self.install_package()

        #Set agent name as per configuration
        agent_details = self.config['agent']
        self.name = agent_details['name']

        #Install tools for agent as per configuration
        self.tools = []
        
        #MCP Approach logic
        self.mcp_approach = 3
        self.mcp_server_url = global_variables.env["MCP_URL"]
        self.mcp_auth=self.config["mcp_authorization"]
        if "connector_description" in self.config:
            self.connector_config=self.config["connector_description"]
        else:
            self.connector_config=None
        #Load llm for agent to use
        self.llm = self.load_llm()

        #Create prompts
        self.prompts = self.load_prompts()

        #Build the Google ADK agent
        self.agent = self.create_agent()
        self.db_url=f'mongodb://{global_variables.env["MONGO_DB_HOST"]}:{global_variables.env["MONGO_DB_PORT"]}/' 
        # self.db_name=global_variables.env["MONGO_DB_NAME"]
        self.db_name='google_adk_db'

        #Get memory type
        self.memory_type = self.config.get("memory_type", "external")


        #Create a session service
        if self.memory_type != "external":
            self.session_service = InMemorySessionService()
        
        else:
            self.session_service = MongoSessionService(mongo_url=self.db_url, db_name=self.db_name)
        
        # self.collection='adk_store'
        # self.session_service.collection=self.session_service.db['agents_co']
        #Create session for runner
        asyncio.run(self.session_service.create_session(app_name=self.APP_NAME, user_id=self.USER_ID, session_id=self.SESSION_ID))
        #Create a Runner to run the agent
        self.runner = Runner(agent=self.agent, app_name=self.APP_NAME, session_service=self.session_service)
        
    
    def set_connector_description(self,toolsets):
        if self.connector_config["REST"]:
            for tool in toolsets:
                if getattr(tool, 'name', None) == "rest_connector":
                    tool.description = self.connector_config["REST"]
        return toolsets
    
    #Install pip packages
    def install_package(self, import_name=None):
        print(f"inside install_package:: {self.config}")
        tools = self.config['tools']
        for tool in tools:
            if tool['package_names'] is not None:
                package_names = tool['package_names']   
                print(f"package_name :::: {package_names}")
                for package_name in package_names:
                    print(f"inside for package_name :::: {package_name}")                    
                    try:
                        importlib.import_module(package_name)
                        print(f"'{import_name}' is already installed.")
                    except ImportError:
                        print(f"'{import_name}' not found. Installing '{package_name}'...")
                        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name]) 
    
    #Method to load the llm via LiteLLM (currently uses a fixed model)
    def load_model_properties(self):
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            self.MODEL_NAME = model_additional_properties["MODEL_NAME"]
            self.APP_NAME = model_additional_properties["APP_NAME"]
            self.USER_ID = model_additional_properties["USER_ID"]
            # self.SESSION_ID = model_additional_properties["SESSION_ID"]
            

        #Setting up environment variables as per Litellm requirements!
        for key in model['additional_properties']:
            os.environ[key] = model['additional_properties'][key]

        self.agent_name=self.config["agent"].get("name")
        self.SESSION_ID=self.config.get("instance_id") or "db2f6a62d3c04e6d8ec7909ab88c9369"
        
        return

    def load_llm(self)->Any:
        return LiteLlm(model=self.MODEL_NAME)

    #Get list of tool names from configuration
    def get_tools(self) -> list:
        print(f"inside get_tools:: {self.config}\n")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        if tools is not None:
            for tool in tools:
                tools_name.append(tool['name'])   
        print(f"tools_name ::: {tools_name}")                 
        return tools_name

    #Loads all required tools from local directory and returns a list of function tools
    def load_local_tools(self, tool_names) -> list:
        print(f"inside load tools: {tool_names}")
        builtin_tools_dir = "google.adk.tools"
        custom_tools_dir = "agentic_adapters.adapter_googleadk.tools"
        tools = []
        for name in tool_names:
            found_in_builtin = False
            #Search for tool in built in directory
            try:
                module = importlib.import_module(builtin_tools_dir)
                tools.append(getattr(module, name))
                print(f"[Success] Found {name} in built-in tools directory!")
                found_in_builtin = True
            except:
                print(f"[Error] Cannot load {name}, it does not exist in built-in tools, looking in custom directory!")
            if found_in_builtin: continue
            
            #If tool was not found in built in directory then search in custom directory
            try:
                module = importlib.import_module(f"{custom_tools_dir}.{name}")
                tools.append(getattr(module, name))
                print(f"[Success] Found {name} in custom tools directory!")
            except:
                print(f"[Error] Cannot load {name}, it probably does not exist in custom tools directory.")
        print("Loader finished!")
        return tools
    
    #Method to load prompt for agent 
    def load_prompts(self)->Any:
        print(f"inside load_prompts:: {self.config}")
        agent_details = self.config['agent']

        prompts = agent_details['prompts']
        print(f"prompts :::: {prompts}")
        description = None
        instruction = None
        for prompt in prompts :
            prompt_type = prompt['prompt_type']
            if prompt_type == "description":
                description = prompt['message']               
            if prompt_type == "instruction":
                instruction = prompt['message']                     

        return {
            "description": description, 
            "instruction": instruction
            }

    #Load all tools from MCP Server (also loads specified tools from builtin directory)
    async def load_all_tools(self):
        
        tools = [
            MCPToolset(
                connection_params=SseConnectionParams(
                    url = self.mcp_server_url
                )
            )
        ]

        return tools
    
    #Load select tools from MCP server (also loads tools from built-in tools)

    async def filter_tools(self, carrier):
        """Connects to multiple MCP servers and loads filtered tools"""
        tool_names = self.get_tools()
        toolsets = []
        if self.mcp_servers == []:
            self.mcp_servers.append(self.mcp_server_url)
        mcp_urls = self.mcp_servers
        headers={
                    "Authorization": self.mcp_auth,
                    **carrier
                }
        for url in mcp_urls:
            try:
                toolset = MCPToolset(
                    connection_params=SseConnectionParams(url=url,headers=headers),
                    tool_filter=tool_names
                )
                # await exit_stack.enter_async_context(toolset)  # manage session properly
                toolsets.append(toolset)
                print(f"[✓] Connected to MCP server: {url}")
            except Exception as e:
                print(f"[✗] Failed to connect to MCP server at {url}: {e}")
        if self.connector_config:
            toolsets=self.set_connector_description(toolsets=toolsets)
        if not toolsets:
            print("❌ No MCP servers connected. Falling back to local tools.")
            return self.load_local_tools(tool_names)

        return toolsets

    #Method to create the GoogleADK agent
    def create_agent(self)->Any:
        return Agent(
            name=self.name,
            model=self.llm, 
            description=self.prompts["description"], 
            instruction=self.prompts["instruction"], 
            tools=self.tools,            
            before_model_callback=self.custom_callback_handler.before_model_call,
            after_model_callback=self.custom_callback_handler.after_model_call,
            before_tool_callback=self.custom_callback_handler.before_tool_call,
            after_tool_callback=self.custom_callback_handler.after_tool_call
        )

#     #Agent execution logic
    async def execute_agent_node(self, state: AgentState, cancel_event: asyncio.Event = None,trace_session_id=None, traj_eval = False) -> AgentState:
        if self.mcp_approach == 1:
            generate_server_file(
                output_filename="mcp_servers\\mcp_server.py",
                server_name="Custom MCP server",
                host="localhost",
                port=8004,
                transport="sse",
                tool_names=validate_tools(self.get_tools())
            )
            self.mcp_server_url = run_server("mcp_servers\\mcp_server.py")

        async with AsyncExitStack() as exit_stack:
            process = None

            trace_metadata = {
                    "agent_name": self.config.get('agent_name'),
                    "instance_id": self.SESSION_ID,
                }
            custom_trace_id = self.SESSION_ID.replace("-", "")
            with self.langfuse.start_as_current_span(name=trace_session_id, metadata=trace_metadata, trace_context={"trace_id": trace_session_id if trace_session_id else custom_trace_id}) as span:            
                carrier: dict[str, str] = {}
                inject(carrier)
                print(f"carrier : {carrier}")

            # Load tools based on MCP approach
                match self.mcp_approach:
                    case 1 | 2:
                        print("Getting all tools from MCP server (Approach 1/2)")
                        self.tools = await self.load_all_tools()
                    case 3:
                        print("Getting select tools from MCP server (Approach 3)")
                        self.tools = await self.filter_tools(carrier)
                    case _:
                        print("Not using MCP server, loading tools from local directory")
                        self.tools = self.load_local_tools(self.get_tools())

                self.agent.tools = self.tools

                # Prepare input
                instructions = ["\nInstructions:", "Use function name for self argument in tool calls"]
                instruction_prompt = '\n'.join(instructions)
                input_text = state.get("input", "") + instruction_prompt

                print(f"[EXECUTE] Running agent with input: {input_text}")

                response = "[No response]"
                event_list = []
                tool_call_ids = set()
                tool_response_ids = set()

                # Initial message
                messages_to_send = [types.Content(role='user', parts=[types.Part(text=input_text)])]

                try:
                    while messages_to_send:
                        current_message = messages_to_send.pop(0)
                        events = self.runner.run_async(
                            user_id=self.USER_ID,
                            session_id=self.SESSION_ID,
                            new_message=current_message
                        )

                        async for event in events:
                            event_list.append(event)

                            if cancel_event and cancel_event.is_set():
                                print("[CANCEL] Execution cancelled.")
                                raise asyncio.CancelledError("Agent execution cancelled.")

                            # Handle tool calls
                            if hasattr(event, "tool_calls") and event.tool_calls:
                                for tool_call in event.tool_calls:
                                    tool_call_ids.add(tool_call.id)
                                    try:
                                        result = await self.agent.run_tool(
                                            name=tool_call.function.name,
                                            arguments=tool_call.function.arguments
                                        )
                                        tool_response_ids.add(tool_call.id)

                                        tool_response = types.Content(
                                            role="tool",
                                            tool_call_id=tool_call.id,
                                            parts=[types.Part(text=result)]
                                        )

                                        # Queue tool response for next loop
                                        messages_to_send.append(tool_response)

                                    except Exception as e:
                                        print(f"[ERROR] Tool execution failed: {e}")
                                        tool_response_ids.add(tool_call.id)

                            # Handle final assistant message
                            if event.is_final_response():
                                if event.content and event.content.parts:
                                    response = event.content.parts[0].text
                                break

                        # Exit the loop if final response was received
                        if event.is_final_response():
                            break

                    # Ensure no tool calls were missed
                    missing = tool_call_ids - tool_response_ids
                    if missing:
                        raise Exception(f"Missing tool responses for tool_call_ids: {missing}")

                except asyncio.CancelledError as e:
                    print("[INFO] Agent execution cancelled and cleaned.")

                    # 🆕 Reset session to prevent LiteLLM from reusing broken message state
                    await self.session_service.delete_session(
                                            app_name=self.APP_NAME,
                                            user_id=self.USER_ID,
                                            session_id=self.SESSION_ID,
                                        )

                    await self.session_service.create_session(app_name=self.APP_NAME, user_id=self.USER_ID, session_id=self.SESSION_ID)

                    return {"status": "cancelled", "message": "agent terminated"}

                except Exception as e:
                    print(f"[ERROR] GoogleADK agent execution failed: {e}")
                    return {"status": "failure", "message": str(e)}

                finally:
                    if process:
                        process.terminate()

            if traj_eval:
                return self.get_googleadk_trajectory(input_text, event_list)

            return response or "[No response]"





        
    async def run(self, input: str, params=None, traj_eval=False, cancel_event: asyncio.Event = None,mcp_authorization=None,trace_session_id=None) -> Any:
        self.mcp_auth=mcp_authorization
        print(f"\n\n\n input in run ::: {input} \n\n\n")
        fixer = """Use proper markdown formatting strictly for display content. Do not apply any markdown formatting (e.g., backticks, asterisks) to file paths, dictionary keys, or values.

    When using a retrieval tool to display data:
    - Format the data in markdown for readability, but exclude file paths from markdown formatting.

    For function calls:
    - Include the function name if the function requires it.

    For image generation:
    - Return only a raw JSON object with no additional text, explanation, or formatting.

    For outputs that include file paths:
    - Ensure there is only one forward slash between directories.
    - Return a dictionary in the following format:

        {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt,
            "response": Markdown-based agent response summary
        }

    If the tool returns only:
        {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt
        }

    Then automatically append the "response" key with a markdown-formatted agent response summary, resulting in the four-key dictionary structure shown above.

    Do not wrap the dictionary output in markdown formatting. Do not include any extra text or symbols around the JSON.
    """
        input += fixer
        if params is not None:
            if params.get('file', ''):
                input += "file path :" + params['file']
            if params.get('tools_id', ''):
                input += "tools_id :" + params['tools_id']
        print("DEBUG", input)

        result = await self.execute_agent_node({"input": input}, cancel_event=cancel_event, trace_session_id=trace_session_id, traj_eval = traj_eval)
        return result



    def get_googleadk_trajectory(self, input : str, adk_events : List[Any]) -> List[Dict[str, Any]]:
        openai_msgs: List[Dict[str, Any]] = []

        # user input is not passed in adk_events, appending it explicitly
        openai_msgs.append({
            "role" : "user",
            "content" : input
        })

        for event in adk_events:
            function_calls = event.get_function_calls() 
            function_responses = event.get_function_responses()

            if function_calls : # assistant call
                tool_calls = []
                for call in function_calls:
                    try:
                        args_json = json.dumps(call.args)
                    except (TypeError, ValueError) as e:
                        args_json = "{}"
                    tool_calls.append({
                        "id": call.id,
                        "type": "function",
                        "function": {
                            "name": call.name,
                            "arguments": args_json
                        }
                    })
                if tool_calls:
                    openai_msgs.append({
                        "role": "assistant",
                        "tool_calls": tool_calls,
                        "content" : ""
                    })

            elif function_responses : # tool response 
                for resp in function_responses:
                    result = resp.response.get("result")
                    if not result:
                        continue
                    content_text = "\n".join([
                        part.text for part in result.content if hasattr(part, "text")
                    ])
                    openai_msgs.append({
                        "role": "tool",
                        "tool_call_id": resp.id,
                        "name": resp.name,
                        "content": content_text
                    })

            else : 
                if event.content:
                    text = "\n".join([
                        part.text for part in event.content.parts if hasattr(part, "text")
                    ])
                    if text.strip():
                        openai_msgs.append({
                            "role": "assistant",
                            "content": text.strip()
                        })

        return openai_msgs
