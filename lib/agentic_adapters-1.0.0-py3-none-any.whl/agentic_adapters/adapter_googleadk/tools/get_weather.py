def get_weather(city:str)->str:
	"""Returns the weather in specific city:
		args:
		city->str
	"""
	return f"The weather in {city} is fantastic!"