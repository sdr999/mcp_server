import os
import json
from pathlib import Path

def read_file(file_path: str) -> str:
    """
    Read contents of a text file.
    
    Args:
        file_path: Path to the file to read
    
    Returns:
        Contents of the file or error message
    """
    try:
        path = Path(file_path)
        if not path.exists():
            return f"Error: File '{file_path}' not found"
        
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return f"File contents of '{file_path}':\n{content}"
    except Exception as e:
        return f"Error reading file: {str(e)}"
