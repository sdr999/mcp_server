import os
import json
from pathlib import Path

def list_directory(directory_path: str = ".") -> str:
    """
    List contents of a directory.
    
    Args:
        directory_path: Path to the directory to list
    
    Returns:
        List of files and directories
    """
    try:
        path = Path(directory_path)
        if not path.exists():
            return f"Error: Directory '{directory_path}' not found"
        
        if not path.is_dir():
            return f"Error: '{directory_path}' is not a directory"
        
        items = []
        for item in sorted(path.iterdir()):
            item_type = "DIR" if item.is_dir() else "FILE"
            size = item.stat().st_size if item.is_file() else "-"
            items.append(f"{item_type:4} {size:>10} {item.name}")
        
        result = f"Contents of '{directory_path}':\n"
        result += "\n".join(items) if items else "Directory is empty"
        
        return result
    except Exception as e:
        return f"Error listing directory: {str(e)}"