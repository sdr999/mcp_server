def search_tool(input: str)->str:
	"""Search tool for GoogleADK"""
	return 'GoogleADK Search Tool testing'