import os
import json
from pathlib import Path

def write_file(file_path: str, content: str) -> str:
    """
    Write content to a text file.
    
    Args:
        file_path: Path where to write the file
        content: Content to write to the file
    
    Returns:
        Success message or error
    """
    try:
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return f"Successfully wrote content to '{file_path}'"
    except Exception as e:
        return f"Error writing file: {str(e)}"