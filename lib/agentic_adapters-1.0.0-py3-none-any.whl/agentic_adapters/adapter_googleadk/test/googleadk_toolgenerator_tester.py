import sys
import os

sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..", "..")))
from agentic_adapters.adapter_googleadk.googleadk_tool_generator import GoogleADKToolGenerator

#use custom tool_config to test if tool generation works
tool_config = {
    "source_code":"def search_tool(input: str)->str:\n\t\"\"\"Search tool for GoogleADK\"\"\"\n\treturn 'GoogleADK Search Tool testing'",
    "name":"search_tool"
}
gen = GoogleADKToolGenerator()

gen.generate(tool_config)