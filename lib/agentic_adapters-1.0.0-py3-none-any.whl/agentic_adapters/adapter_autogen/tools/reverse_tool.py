def reverse_tool(input_str: str) -> str:
    """Reverses the input string."""
    return input_str[::-1]
 
