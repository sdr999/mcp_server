def word_count_tool(input_str: str) -> str:
    """Counts the number of words."""
    return f"Word count: {len(input_str.split())}"