def shout_tool(input_str: str) -> str:
    """Converts input to uppercase."""
    return input_str.upper()
 
