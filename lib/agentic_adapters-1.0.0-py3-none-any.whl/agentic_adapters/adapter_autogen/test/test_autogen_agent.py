import asyncio
import sys
import os
sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..", "..")))
# from agentic_adapters.adapter_autogen.autogen_agent import AutogenAgent
from agentic_framework.core.agent import Agent

async def main():
    # Agent configuration dictionary
    config = {
        "type":"autogen",
        "tool_names": "reverse_tool, shout_tool, word_count_tool",
        "assistant_name": "ReverserAgent",
        "package_names": "autogen",
        "system_prompts": [
            "You are a helpful assistant that can reverse, shout and count words using a tool."
        ]
        }
#  # packages required autogen-agentchat,autogen-ext[openai],autogen-ext[azure]
#     # Instantiate the agent (llmconfig is loaded internally from config.properties)
#     agent = AutogenAgent(config)
 
#     # Sample input to test the agent
#     input_str = "count and shout hello"
 
#     # Run the agent
#     result = await agent.run(input_str=input_str)
#     print(result)
 
    # Instantiate the agent (llmconfig is loaded internally from config.properties)
    AGagent = Agent(config)
    print("Successfully created Agent")
# Sample input to test the agent
#input_str = "Please reverse and shout the word himalaya, then count words in this sentence."

# Run the agent
    result = await AGagent.run("reverse and shout the word himalaya")
    print(result)
 
if __name__ == "__main__":
    asyncio.run(main())
 




#     # Agent configuration dictionary
# config = {
#     "type":"autogen",
#     "tool_names": "reverse_tool, shout_tool, word_count_tool",
#     "assistant_name": "ReverserAgent",
#     "package_names": "autogen",
#     "system_prompts": [
#         "You are a helpful assistant that can reverse, shout and count words using a tool."
#     ]
#     }
# #  # packages required autogen-agentchat,autogen-ext[openai],autogen-ext[azure]
# #     # Instantiate the agent (llmconfig is loaded internally from config.properties)
# #     agent = AutogenAgent(config)
 
# #     # Sample input to test the agent
# #     input_str = "count and shout hello"
 
# #     # Run the agent
# #     result = await agent.run(input_str=input_str)
# #     print(result)
 
#     # Instantiate the agent (llmconfig is loaded internally from config.properties)
# AGagent = Agent(config)
# print("Successfully created Agent")
# # Sample input to test the agent
# #input_str = "Please reverse and shout the word himalaya, then count words in this sentence."

# # Run the agent
# result = await AGagent.run("reverse and shout the word himalaya")
# print(result)
 





# from agentic_adapters.adapter_autogen.autogen_agent import AutogenAgent
#  async def main():
#     # Agent configuration dictionary
#     config = {
#         "type":"autogen",
#         "tool_names": "reverse_tool, shout_tool, word_count_tool",
#         "assistant_name": "ReverserAgent",
#         "package_names": "autogen, openai, autogen-agentchat",
#         "system_prompts": [
#             "You are a helpful assistant that can reverse, shout and count words using a tool."
#         ]
#     }
 
#     # Instantiate the agent (llmconfig is loaded internally from config.properties)
#     agent = AutogenAgent(config)
#     print("Successfully created Agent")
#     # Sample input to test the agent
#     agent = AutogenAgent(config)
 
#     # Sample input to test the agent
#     input_str = "count and shout hello"
 
#     # Run the agent
#     result = await agent.run(input_str=input_str)
#     print(result)
 
# if __name__ == "__main__":
#     asyncio.run(main())