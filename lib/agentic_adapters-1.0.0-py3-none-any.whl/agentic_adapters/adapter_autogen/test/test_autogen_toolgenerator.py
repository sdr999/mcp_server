import sys
import os
import json
sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..", "..")))
from agentic_adapters.adapter_autogen.autogen_tool_generator import AutogenToolGenerator

#use custom tool_config to test if tool generation works
def test_generate_tool():
    print("test_generate_tool")
    
    test_dir = os.path.dirname(os.path.abspath(__file__))
    data_file_path = os.path.join(test_dir, "data", "test-tool-data.json")  
    with open(data_file_path) as f:
        data = json.load(f)
    tool_generator = AutogenToolGenerator()
    tool_generator.generate(data)


if __name__ == "__main__":
    test_generate_tool()