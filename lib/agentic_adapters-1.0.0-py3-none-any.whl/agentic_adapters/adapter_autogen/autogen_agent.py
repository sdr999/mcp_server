import importlib
import asyncio
import sys
import json
import subprocess
from typing import Any, Dict, List
from agentic_adapters.core.base_agent import BaseAgent
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.conditions import TextMessageTermination
from autogen_agentchat.teams import RoundRobinGroupChat
from  autogen_core.tools import BaseTool  # AutoGen's BaseTool
# from mcp.types import Tool
from autogen_ext.tools.mcp import SseServerParams, mcp_server_tools
from agentic_adapters.utils.mcp_server_generator import generate_server_file, run_server, validate_tools
from agentic_framework.utils import global_variables
# MCP Client imports
from mcp.client.session import ClientSession
from mcp.client.sse import sse_client
from autogen_core.model_context import BufferedChatCompletionContext
from autogen_core.memory import ListMemory, MemoryContent, MemoryMimeType, Memory
#import nest_asyncio
#nest_asyncio.apply()
from pymongo import MongoClient
from typing import List
from datetime import datetime
from langfuse import Langfuse
import openlit
from opentelemetry.propagate import inject



#external memory implemetaion
class MongoMemory(Memory):
    def __init__(self, db_url: str, db_name: str, collection_name: str, session_id: str = "default"):
        self.collection = MongoClient(db_url)[db_name][collection_name]
        self.session_id = session_id

    async def add(self, content: MemoryContent):
        """Append memory to the 'memories' array of the session document."""
        memory_entry = {
            "content": content.content,
            "mime_type": content.mime_type.value if content.mime_type else MemoryMimeType.TEXT.value,
            "timestamp": datetime.utcnow(),
        }

        self.collection.update_one(
            {"session_id": self.session_id},
            {"$push": {"memories": memory_entry}},
            upsert=True
        )
    
    async def query(self, query: str = "") -> List[MemoryContent]:
        """Return memory history for the session from the 'memories' array."""
        doc = self.collection.find_one({"session_id": self.session_id})
        if not doc or "memories" not in doc:
            return []

        return [
            MemoryContent(
                content=mem.get("content"),
                mime_type=MemoryMimeType(mem.get("mime_type", MemoryMimeType.TEXT.value))
            )
            for mem in sorted(doc["memories"], key=lambda x: x.get("timestamp", datetime.utcnow()))
        ]

    async def update_context(self, model_context, **kwargs):
        """Feed memory messages into the model context before agent run."""
        memories = await self.query(kwargs.get("query", ""))
        print("MEMORIES :::",memories)
        await model_context.clear()
        for mem in memories:
            await model_context.add(mem)
            
    async def clear(self):
        """Clear all memories for this session."""
        self.collection.update_one(
            {"session_id": self.session_id},
            {"$set": {"memories": []}}
        )

    async def close(self):
        self.client.close()



class AutogenAgent(BaseAgent):
    def __init__(self, config: Dict):
        self.approach=3
        self.session:ClientSession=None
        self.config = config
        self.langfuse_public_key=global_variables.env['LANGFUSE_PUBLIC_KEY']
        self.langfuse_secret_key=global_variables.env['LANGFUSE_SECRET_KEY']
        self.langfuse_host=global_variables.env['LANGFUSE_HOST']
        self.langfuse = Langfuse(
            secret_key=self.langfuse_secret_key,
            public_key=self.langfuse_public_key,
            host=self.langfuse_host
           )
        openlit.init(tracer=self.langfuse._otel_tracer, event_logger=True, application_name=self.config["agent"].get("name"))        
        self.mcp_servers=self.config["mcp_servers"]
        self.mcp_auth=self.config["mcp_authorization"]
        if "connector_description" in self.config:
            self.connector_config=self.config["connector_description"]
        else:
            self.connector_config=None
        self.llmconfig = self.load_llmconfig()
 
        # Install required packages (this function can be customized)
        self.install_package()
 
        # Setup tools for the agent based on the configuration

        self.tools = []
        self.agent = None
        self.team = None

        #self.tools =  self.load_tools()
 
        # Load the LLM for the agent to use
        self.model_client = self.load_model_client()
 
        # Load the prompts
        self.prompts = self.load_prompts()
 
        # Create the agent
        #self.agent = self.create_agent()

        #self.team = self.loop()

        #self.connection = self.connect_mcp()
        self.db_url=f'mongodb://{global_variables.env["MONGO_DB_HOST"]}:{global_variables.env["MONGO_DB_PORT"]}/' 
        self.db_name=global_variables.env["MONGO_DB_NAME"]
        self.agent_name=self.config["agent"].get("name")
        self.instance_id=self.config.get("instance_id") or self.agent_name
        self.memory = MongoMemory(self.db_url, self.db_name, "agent_sessions",self.instance_id)
        self.memo=None
        self.memory_type=self.config.get("memory_type") or "external"


    def set_connector_description(self,toolsets):
        if self.connector_config["REST"]:
            for tool in toolsets:
                if getattr(tool, 'name', None) == "rest_connector":
                    tool.description = self.connector_config["REST"]
        return toolsets           
 
    def load_llmconfig(self) -> dict:
        print("inside load llm :: :: ::")
        # print(f"inside load_llm:: {self.config['models']}")
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        # print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
                # Construct llmconfig dictionary for the first model with additional_properties found
                llmconfig = {
                    "provider": model_additional_properties["provider"],
                    "config": {
                        "model": model_additional_properties["model"],
                        "azure_endpoint": model_additional_properties["AZURE_OPENAI_ENDPOINT"],
                        "azure_deployment": model_additional_properties["AZURE_OPENAI_DEPLOYMENT_NAME"],
                        "api_version": model_additional_properties["AZURE_OPENAI_API_VERSION"],
                        "api_key": model_additional_properties["AZURE_OPENAI_API_KEY"],
                    }
                }
                return llmconfig
        # Return empty dict if no model additional_properties found
        return {}

    # This is to pip install library
    def install_package(self, import_name=None):
        print("inside load package :: :: ::")
        # print(f"inside install_package:: {self.config}")
        tools = self.config['tools']
        #package_names = ""
        for tool in tools:
            if tool['package_names'] is not None:
                package_names = tool['package_names']   
                print(f"package_name :::: {package_names}")
                for package_name in package_names:
                    print(f"inside for package_name :::: {package_name}")                    
                    try:
                        importlib.import_module(package_name)
                        print(f"'{import_name}' is already installed.")
                    except ImportError:
                        print(f"'{import_name}' not found. Installing '{package_name}'...")
                        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name]) 

    #get list of tool names from configuration
    def get_tools(self) -> list:
        print("inside get tools :: :: ::")
        # print(f"inside get_tools:: {self.config}\n")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        if tools is not None:
            for tool in tools:
                tools_name.append(tool['name'])   
        print(f"tools_name ::: {tools_name}")                 
        return tools_name

    # loads all required tools and returns a list of function tools
    async def load_tools(self, carrier):
        all_tools = []
        headers={
            "Authorization":self.mcp_auth,
            **carrier
        }
        # Loop over multiple MCP servers
        for mcp_url in self.mcp_servers:
            print(f"[INFO] Connecting to MCP server: {mcp_url}")
            server_params = SseServerParams(
                url=mcp_url,
                headers=headers,
                timeout=10,
                sse_read_timeout=300,
            )
            try:
                tools = await mcp_server_tools(server_params=server_params)
                print(f"[INFO] Tools from {mcp_url}: {tools}")
                all_tools.extend(tools)
            except Exception as e:
                print(f"[ERROR] Failed to fetch tools from {mcp_url}: {e}")

        # If approach == 1 or 2, just return everything
        if self.approach in [1, 2]:
            return all_tools

        # Otherwise filter based on config
        requested_tools = self.get_tools()
        filtered_tools = []
        for tool_name in requested_tools:
            tool_info = next((t for t in all_tools if t.name == tool_name), None)
            if tool_info:
                filtered_tools.append(tool_info)

        print(f"[INFO] Filtered tools: {filtered_tools}")
        if self.connector_config:
            filtered_tools=self.set_connector_description(toolsets=filtered_tools)
        return filtered_tools

    def load_model_client(self):
        """Load the LLM from Azure."""
        print("Loading Azure LLM...")
        # Import here after ensuring packages are installed
        import importlib
        importlib.import_module('openai')  # Ensure openai is loaded
        from autogen_core.models import ChatCompletionClient
        client = ChatCompletionClient.load_component(self.llmconfig)
        return client
 
    def load_prompts(self) -> str:
        print("inside load prompts :: :: ::")
        # print(f"inside load_prompts:: {self.config}")
        agent_details = self.config['agent']
        prompts = agent_details['prompts']
        # print(f"prompts :::: {prompts}")
        # Collecting system prompts in a list
        system_prompts = []
    
        for prompt in prompts:
            prompt_type = prompt['prompt_type']
            if prompt_type == "system-prompt":
                message = prompt['message']  
                system_prompts.append(message)

        system_prompt = ". \n".join(system_prompts)
        # print(f'prompt ::: {system_prompt}')  
        return system_prompt
 
    def create_agent(self) -> AssistantAgent:
        """Create the agent."""


        print("Creating Assistant Agent...")
        if self.memory_type =="external":
            self.memo = ListMemory()
        agent_details = self.config['agent']
        agent = AssistantAgent(
            name=agent_details['name'],
            model_client=self.model_client,
            tools=self.tools,
            system_message=self.prompts,
            memory=[self.memo] if self.memo else None,
            model_context=BufferedChatCompletionContext(buffer_size=20) if self.memo else None,
        )
        return agent

    '''async def execute_prompt(self, agent: Agent, prompt: str) -> AgentState:
        """Execute the prompt and return the response"""
        self.tools=await self.connect_mcp()
        print("\n\n\n\nToools from connect mcp *******************",self.tools)
        run = agent.run(prompt)
        print(run.content)
        return run.content'''
 
    def loop(self) -> RoundRobinGroupChat:
        """Create team to run single agent in a loop"""
        print("inside loop")
        agent_details = self.config['agent']
        # Termination condition that stops the task if the agent responds with a text message.
        termination_condition = TextMessageTermination(agent_details['name'])
        print(f"termination: {agent_details['name']}")
        # Create a team with the looped assistant agent and the termination condition.
        team = RoundRobinGroupChat(
            [self.agent],
            termination_condition=termination_condition,
        )
        return team

    async def execute_agent(self, input_str: str, cancel_event: asyncio.Event = None, trace_session_id= None, traj_eval = False) -> dict:
        print(f"Executing agent with input: {input_str}")

        try:
            
            trace_metadata = {
                "agent_name": self.config.get('agent_name'),
                "instance_id": self.instance_id,
            }
            custom_trace_id = self.config.get('instance_id').replace('-', '') if self.config.get('instance_id') else  self.config.get('agent_name')
            with self.langfuse.start_as_current_span(name=trace_session_id, metadata=trace_metadata, trace_context={"trace_id": trace_session_id if trace_session_id else custom_trace_id}) as span:
                carrier: dict[str, str] = {}
                inject(carrier)
                print(f"\n\n\n\n+++++++++++++++ Carrier: {carrier}++++++++++++++\n\n\n")

                self.tools = await self.load_tools(carrier)
                self.agent = self.create_agent()
                self.team = self.loop()

                if self.memory_type == "external":
                    await self.memory.update_context(self.memo)
                
                run_task = asyncio.create_task(self.team.run(task=input_str))

                while not run_task.done():
                    await asyncio.sleep(0.2)
                    if cancel_event and cancel_event.is_set():
                        run_task.cancel()
                        print("[INFO] Agent execution cancelled.")
                        raise asyncio.CancelledError("Agent execution was cancelled.")

                response = await run_task

        except asyncio.CancelledError as e:
            return {"status": "cancelled", "message": "agent terminated"}
        except Exception as e:
            print(f"[ERROR] Agent execution failed: {e}")
            return {"status": "failure", "message": str(e)}

        final_response = ''
        if response.messages[-1] is not None:
            print("response :: :: :: ", response)
            final_response = response.messages[-1].content

        print("final response :: :: ::", final_response)

        if self.memory_type == "external":
            input_strg = "Question : " + input_str
            await self.memory.add(MemoryContent(mime_type=MemoryMimeType.TEXT, content=input_strg))
            await self.memory.add(MemoryContent(mime_type=MemoryMimeType.TEXT, content=final_response))

        if traj_eval:
            trajectory = self.get_autogen_trajectory(response.messages)
            return trajectory

        return final_response

 
    async def run(self, input: str, params =None, traj_eval = False, cancel_event: asyncio.Event = None,mcp_authorization=None, trace_session_id=None) -> dict:
        self.mcp_auth=mcp_authorization
        """Interface for the agent to process input."""
        print(f"\n\n\n input in run ::: {input} \n\n\n")
        print(f"\n\n\n input in run ::: {params} \n\n\n")
        fixer ="""Use proper markdown formatting strictly for display content. Do not apply any markdown formatting (e.g., backticks, asterisks) to file paths, dictionary keys, or values.

When using a retrieval tool to display data:
- Format the data in markdown for readability, but exclude file paths from markdown formatting.

For function calls:
- Include the function name if the function requires it.

For image generation:
- Return only a raw JSON object with no additional text, explanation, or formatting.

For outputs that include file paths:
- Ensure there is only one forward slash between directories.
- Return a dictionary in the following format:

    {
        "file_name": file_name,
        "file_path": file_path,
        "prompt": prompt,
        "response": Markdown-based agent response summary
    }

If the tool returns only:
    {
        "file_name": file_name,
        "file_path": file_path,
        "prompt": prompt
    }

Then automatically append the "response" key with a markdown-formatted agent response summary, resulting in the four-key dictionary structure shown above.

Do not wrap the dictionary output in markdown formatting. Do not include any extra text or symbols around the JSON.
"""
        input += fixer
        if params is not None:
            if params.get('file',''):
                input += "file path :"+params['file']
            if params.get('tools_id',''):
                input += "tools_id :"+params['tools_id']
        print("DEBUG",input)
        return await self.execute_agent(input, cancel_event=cancel_event,trace_session_id=trace_session_id, traj_eval = traj_eval) 
    
    
    def get_autogen_trajectory(
        self,
        messages: List,
    ) -> List[Dict[str, Any]]:
        openai_msgs : List[Dict[str, Any]] = []

        for msg in messages:
            
            msg_type = msg.type

            if msg_type == "TextMessage":
                role = "user" if msg.source == "user" else "assistant"
                openai_msgs.append({"role": role, "content": msg.content or ""})

            elif msg_type == "ToolCallRequestEvent":
                tool_calls = []
                for tool_call in msg.content:
                    tool_calls.append(
                        {
                            "id": tool_call.id,
                            "type": "function",
                            "function": {
                                "name": tool_call.name,
                                "arguments": tool_call.arguments,
                            },
                        }
                    )
                openai_msgs.append(
                    {"role": "assistant", "content": "", "tool_calls": tool_calls}
                )

            elif msg_type == "ToolCallExecutionEvent":
                for result in msg.content:
                    openai_msgs.append(
                        {
                            "role": "tool",
                            "content": result.content,
                            "name": result.name,
                            "tool_call_id": result.call_id
                        }
                    )

            
        return openai_msgs