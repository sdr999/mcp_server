import sys
import os

sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..", "..")))
import asyncio
from agentic_framework.core.agent import Agent

agent_config = {
    "type":"semantic-kernel",
    "package_names":"semantic-kernel==1.35.0",
    "agent_name":"HelperAgent", 
    "description":"Assist user with their queries using functions or tools from mcp server",
    "tools":"search_tool,youtube,wikipedia",
    "mcp_server_url":"http://10.20.0.61:8000/sse",
    "mcp_approach":3,
    "models":[{
                "additional_properties":{
                    "MODEL_NAME" : "azure/gpt-4",
                    #"MODEL_NAME" : "gemini/gemini-2.0-flash",
                    "APP_NAME" : "AgenticApp",
                    "USER_ID" : "agent_user",
                    "SESSION_ID" : "1234",
                    "AZURE_API_KEY":"AH21iQAhXYlBfEUxuviKr4bgy2OY7GwB47FsDqZkrQmrJLPUDXLpJQQJ99BCACYeBjFXJ3w3AAABACOGdBgW",
                    "AZURE_API_BASE":"https://openaidigitalmeltingpotgpt.openai.azure.com/",
                    "AZURE_API_VERSION":"2024-10-21"
                }
            }
        ]
    }



SKAgent = Agent(agent_config)

print("Successfully created Agent")
while True:
    inp=input()
    if inp=='q':break
    
    data = asyncio.run(SKAgent.run(inp))

    print(data)