import sys
import os
import asyncio
sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..", "..")))

from agentic_framework.core.agent import Agent

agent_config = {
    "type":"semantic-kernel",
    "package_names":"semantic-kernel==1.35.0",
    "mcp_server_url":"http://10.20.0.61:8000/sse",
    "mcp_approach":3,
    "agent":{"name":"HelperAgent",
             "prompts":
                [
                    {"prompt_type":"description","message":"A helper agent that uses a set of tools to assist the user"},
                    {"prompt_type":"instruction","message":"You will help user with their queries. You have a set of tools use them appropriately and help the user. You different tools as per query requirements"}
                ]
    }, 
    "tools":[{"name":"retrieve_csv","package_names":None},{"name":"read_file","package_names":None},{"name":"get_weather","package_names":None},{"name":"color_tool","package_names":None}],
    "models":[{
                "additional_properties":{
                    "MODEL_NAME" : "azure/gpt-4",
                    #"MODEL_NAME" : "gemini/gemini-2.0-flash",
                    "APP_NAME" : "AgenticApp",
                    "USER_ID" : "agent_user",
                    "SESSION_ID" : "1234",
                    "AZURE_API_KEY":"AH21iQAhXYlBfEUxuviKr4bgy2OY7GwB47FsDqZkrQmrJLPUDXLpJQQJ99BCACYeBjFXJ3w3AAABACOGdBgW",
                    "AZURE_API_BASE":"https://openaidigitalmeltingpotgpt.openai.azure.com/",
                    "AZURE_API_VERSION":"2024-10-21"
                }
            }
        ]
    }

async def main():
    ADKAgent = Agent(agent_config)

    print("Successfully created Agent")
    data = await ADKAgent.run("Using your retrieve csv tool show me records with status as Upcoming.")

    print(f"Input:{data["input"]}\nOutput:{data["output"]}")

asyncio.run(main())