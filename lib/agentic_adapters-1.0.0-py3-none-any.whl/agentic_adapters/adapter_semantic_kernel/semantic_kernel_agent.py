from agentic_adapters.utils.mcp_server_generator import generate_server_file, run_server, validate_tools
import os
import json
from typing import Any, Dict
from typing import TypedDict
from agentic_adapters.core.base_agent import BaseAgent
import subprocess
import sys
import importlib
from agentic_framework.utils import global_variables

import semantic_kernel as sk
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion, OpenAIPromptExecutionSettings, AzureChatPromptExecutionSettings
from semantic_kernel.contents import ChatHistory
import time
from dataclasses import dataclass
from typing import Annotated, List, Optional
from semantic_kernel.connectors.ai.open_ai.services.azure_text_embedding import AzureTextEmbedding
from semantic_kernel.connectors.mongodb import MongoDBAtlasStore
from semantic_kernel.connectors.mcp import MCPSsePlugin
from semantic_kernel.data.vector import VectorStoreField, vectorstoremodel
from pymongo import MongoClient
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior
# Getting constants from properties.json
import logging
import asyncio
from langfuse import Langfuse, observe
import openlit
from opentelemetry.propagate import inject

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

#base_dir = os.path.dirname(os.path.abspath(__file__))
#properties_dir = os.path.join(base_dir, "config", "properties.json")

#with open(properties_dir, "r") as f:
 #   data = json.load(f)



class AgentState(TypedDict):
    input: str
    history: list
    output: str



class CustomCallbackHandler():
    _after_model_func:str =None
    _before_model_func:str =None
    _after_tool_func:str =None
    _before_tool_func:str= None
    model_function=None
    tools_function=None

    def __init__(self,functions:Any=None):
        if functions is not None:
            self.model_function=functions["model"] 
            self.tools_function=functions["tools"] 
            self._before_model_func=self.model_function["before"] 
            self._after_model_func=self.model_function["after"]
        # self._before_tool_func=before_tool_func
        # self._after_tool_func=after_tool_func
    # Tool Start
    def before_tool_call(self,tool:Any,*args,**kwargs):
        print("before tool call executed:: :: :: ::")
        
        try:
            if self.tools_function is not None: 
                self._before_tool_func=self.tools_function[tool.name]["before"]
                if self._before_tool_func is not None:
                    exec(self._before_tool_func,{"self": self})
        except Exception as e:
            
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # Tool End
    def after_tool_call(self,tool:Any,*args,**kwargs):
        try:
            if self.tools_function is not None: 
                self._after_tool_func=self.tools_function[tool.name]["after"]
                if self._after_tool_func is not None:
                    exec(self._after_tool_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # LLM Start
    def before_model_call(self,*args,**kwargs):
        try:
            if self.model_function is not None: 
                if self._before_model_func is not None:
                    exec(self._before_model_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
 
    # LLM End
    def after_model_call(self,*args,**kwargs):
        try:
            if self.model_function is not None:
                if self._after_model_func is not None:
                    exec(self._after_model_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")


class SemanticKernelAgent():
    def __init__(self, config: dict):
        # init config details
        self.config = config
        self.kernel = sk.Kernel()
        # Create a method to load model properties like API keys and other prerequisites
        self.model_setup()
        # self.load_model_properties()

        # install required packages
        self.install_package()

        # install tools for agent as per config
        # self.tools = self.load_tools(self.get_tools())
        # installs tools dynamically
        self.tools = []
        self.filter={"included_functions":[]}
        self.ft=self.get_tools()
        print('ft:',self.ft)
        self.mcp_plu=[]
    
        self.db_url=f'mongodb://{global_variables.env["MONGO_DB_HOST"]}:{global_variables.env["MONGO_DB_PORT"]}/' 
        # self.db_name=global_variables.env["MONGO_DB_NAME"]
        self.db_name='sk_memory_db'
        

       #MCP Approach logic
        self.mcp_approach = 3
        # self.mcp_server_url = global_variables.env["MCP_URL"]
        print('mcp servers here:',self.config['mcp_servers'])
        self.mcp_servers=self.config['mcp_servers']
        self.mcp_auth=self.config["mcp_authorization"]

        # create prompts
        # self.prompts = self.load_prompts()
        
        self.service_id='default'
        # self.session_id='1234'
        self.session_id = self.config.get('instance_id') or self.config.get("agent").get("name")
        # self.service_id=self.SESSION_ID

        # Build the Semantic Kernel AI agent
        # self.chat_service = self.create_agent()
        self.chat_service=self.load_llm()
        
        self.kernel.add_service(self.chat_service)
        
        self.embedding_service=self.create_embedding()
        self.kernel.add_service(self.embedding_service)
        
        self.langfuse = Langfuse(
            public_key = global_variables.env['LANGFUSE_PUBLIC_KEY'],
            secret_key = global_variables.env['LANGFUSE_SECRET_KEY'],
            host = global_variables.env['LANGFUSE_HOST']
        )
       
        openlit.init(tracer=self.langfuse._otel_tracer, disable_batch=True)


    # install pip packages
    def install_package(self, import_name=None):
        print(f"inside install_package:: {self.config}")
        if 'package_names' in self.config:
            package_names = self.config['package_names']
            packages = [pkg.strip() for pkg in package_names.split(",") if pkg.strip()]
            """
            Installs a package using pip if it isn't already installed.

            Args:
                package_name (str): The name used with pip to install the package.
                import_name (str): The name used to import the module (if different from package_name).
            """
            for package_name in packages:
                import_name = package_name
                try:
                    importlib.import_module(import_name)
                    print(f"'{import_name}' is already installed.")
                except ImportError:
                    print(f"'{import_name}' not found. Installing '{package_name}'...")
                    subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])

    

    async def ensure_atlas_indexes(self):
        """Ensure all necessary indexes exist in MongoDB Atlas"""
        try:
            # Get the raw MongoDB client
            # client = MongoClient(os.getenv("MONGODB_CONNECTION_STRING", "mongodb://localhost:27017/"))
            client = MongoClient(self.db_url)
           
            # db = client["sk_memory_db"]
            db=client[self.db_name]
            collection = db["conversations"]
            
            # Check if indexes exist
            indexes = list(collection.list_indexes())
            vector_index_exists = any(index.get("name") == "vector_index" for index in indexes)
            text_index_exists = any(index.get("name") == "text_index" for index in indexes)
            
            # Create vector index if it doesn't exist (MongoDB Atlas specific syntax)
            if not vector_index_exists:
                print("Creating vector search index in MongoDB Atlas...")
                try:
                    # Correct syntax for MongoDB Atlas vector search index [citation:5]
                    search_index_model = {
                        "name": "vector_index",
                        "type": "vectorSearch",
                        "definition": {
                            "fields": [
                                {
                                    "type": "vector",
                                    "path": "vector",
                                    "numDimensions": 1536,
                                    "similarity": "cosine"
                                }
                            ]
                        }
                    }
                    collection.create_search_index(search_index_model)
                    print(" ::: Vector search index created successfully for MongoDB Atlas ::: ")
                except Exception as vec_error:
                    print('Now storing data in mongodb ... ')
                    # print(f"Failed to create vector index: {vec_error}")
                    
            # Create text index if it doesn't exist
            if not text_index_exists:
                print("Creating text index in MongoDB...")
                try:
                    collection.create_index([("text", "text")], name="text_index")
                    print(" ::: Text index created successfully :::")
                except Exception as text_error:
                    print(f"::: Failed to create text index: {text_error} :::")
            else:
                print("::: Text index already exists :::")
                
            client.close()
            return True
        except Exception as e:
            print(f"::: Failed to create indexes: {e} :::")
            return False
    

    async def external_memory_mongodb(self,query, collection, embedding_service):
        """Retrieve relevant context from MongoDB memory"""
        try:
            query_embedding = await embedding_service.generate_embeddings([query])
            vec = query_embedding[0]
            
            if hasattr(vec, 'ndim') and vec.ndim > 1:
                vec = vec.flatten().tolist()
            elif hasattr(vec, '__iter__') and not isinstance(vec, list):
                vec = list(vec)
                
            # Verify vector dimensions this if or logging purpose
            if len(vec) != 1536:
                print(f" :::  Warning: Vector dimension is {len(vec)}, expected 1536 ::::")

            
            memory_context = "No previous context found"
            try:
                results = await collection.search(vector=vec, limit=3, filters={"session_id":self.session_id})
                
                if results:
                    context_items = []
                    if hasattr(results, '__aiter__'):
                        async for result in results:
                            text_content = getattr(result, 'text', None)
                            if text_content:
                                context_items.append(f"- {text_content}")
                    else:
                        for result in results:
                            text_content = getattr(result, 'text', None)
                            if text_content:
                                context_items.append(f"- {text_content}")
                    
                    if context_items:
                        memory_context = "\n".join(context_items)
                        print(f"::: Found {len(context_items)} relevant previous conversations using vector search :::")
                    else:
                        print("No text content found in search results based on previous conversation")
                        
            except Exception as e:
                print('vector search failed:',e)
                try:
                    client = MongoClient(self.db_url)
                    db = client[self.db_name]
                    conversations_col = db["conversations"]
                    
                    text_results = conversations_col.find(
                        {"$text": {"$search": query}, "session_id":self.session_id},
                        {"text": 1, "_id": 0}
                    ).limit(3)
                    
                    text_contexts = []
                    for doc in text_results:
                        if 'text' in doc:
                            text_contexts.append(f"- {doc['text']}")
                    
                    if text_contexts:
                        memory_context = "\n".join(text_contexts)
                    
                    client.close()
                except Exception as text_error:
                    print(f" :::  Text search also failed: {text_error}. Using regex search as last resort...")
                    try:
                        client = MongoClient(self.db_url)
                        db = client[self.db_name]
                        conversations_col = db["conversations"]
                        
                        regex_results = conversations_col.find(
                            {"text": {"$regex": query, "$options": "i"}},
                            {"text": 1, "_id": 0}
                        ).limit(3)
                        
                        regex_contexts = []
                        for doc in regex_results:
                            if 'text' in doc:
                                regex_contexts.append(f"- {doc['text']}")
                        
                        if regex_contexts:
                            memory_context = "\n".join(regex_contexts)
                            print(f"Found {len(regex_contexts)} relevant conversations using regex search")
                        else:
                            print("No results found in regex search")
                        
                        client.close()
                    except Exception as regex_error:
                        print(f"  Regex search also failed: {regex_error}. Continuing without context...")
            
            return memory_context
        except Exception as e:
            print(f"Memory not found  or Error in memory retrieval: {e} :::")
            return "No previous context found"
    
    @vectorstoremodel
    @dataclass
    class Conversation:
        id: Annotated[str, VectorStoreField("key")]
        session_id: Annotated[str, VectorStoreField("data", is_indexed=True)] # for session based memory
        text: Annotated[str, VectorStoreField("data", is_indexed=True, is_full_text_indexed=True)]
        embedding: Annotated[Optional[List[float]], VectorStoreField(
            "vector", 
            dimensions=1536, 
            distance_function="cosine"
        )] = None

        def __post_init__(self):
            if self.embedding is None:
                self.embedding = []

    '''
    # Model setup logic (NEEDS TO CHANGE TO ADAPT TO NEW MODEL_PROPERTIES CONFIG)
    def load_model_properties(self):
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            self.MODEL_NAME = model_additional_properties["MODEL_NAME"]
            self.APP_NAME = model_additional_properties["APP_NAME"]
            self.USER_ID = model_additional_properties["USER_ID"]
            self.SESSION_ID = model_additional_properties["SESSION_ID"]


        #Setting up environment variables as per Litellm requirements!
        for key in model['additional_properties']:
            os.environ[key] = model['additional_properties'][key]
        
        return
    '''
    #Method to load the llm via LiteLLM (currently uses a fixed model)
    def load_llm(self) -> Any:
        
        print(f"inside load_llm:: {self.config['models']}")
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            self.embedding_key=model_additional_properties['AZURE_OPENAI_API_KEY']
            self.embedding_deploy_name=global_variables.env["EMBEDDING_DEPLOYMENT_NAME"]
            self.embedding_endpoint=model_additional_properties['AZURE_OPENAI_ENDPOINT']
            self.embedding_version=model_additional_properties['AZURE_OPENAI_API_VERSION']
            azure_chat_openAI=AzureChatCompletion(
                    service_id=self.service_id,
                    deployment_name=model_additional_properties['AZURE_OPENAI_DEPLOYMENT_NAME'],
                    endpoint=model_additional_properties['AZURE_OPENAI_ENDPOINT'],
                    api_key=model_additional_properties['AZURE_OPENAI_API_KEY'],
                ) # type: ignore
            return azure_chat_openAI
    
    def model_setup(self):
        #os.environ["MODEL_NAME"] = data["MODEL_NAME"]
        # loading api key, api base, api version
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            self.MODEL_NAME = model_additional_properties["MODEL_NAME"]
            self.APP_NAME = model_additional_properties["APP_NAME"]
            # self.API_VERSION = model_additional_properties["AZURE_OPENAI_API_VERSION"]
            self.USER_ID = model_additional_properties["USER_ID"]
            # self.SESSION_ID = model_additional_properties["SESSION_ID"]
            self.embedding_key=model_additional_properties['AZURE_OPENAI_API_KEY']
        for key in model['additional_properties']:
            os.environ[key] = model['additional_properties'][key]
    '''
    # get list of tool names from configuration
    def get_tools(self) -> list:
        print(f"inside get_tools:: {self.config}\n")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        tools_name=tools.split(',')             
        return tools_name
    '''
    
    def get_tools(self) -> list:
        print(f"inside get_tools:: {self.config}\n")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        if tools is not None:
            for tool in tools:
                tools_name.append(tool['name'])   
        print(f"tools_name ::: {tools_name}")                 
        return tools_name
        
   
   # loads all required tools and returns a list of function tools
    def load_tools(self, tool_names) -> list:
        print(f"inside load tools: {tool_names}")
        builtin_tools_dir = "semantic-kernel"
        custom_tools_dir = "agentic_adapters.adapter_semantic_kernel.tools"
        tools = []
        for name in tool_names:
            found_in_builtin = False
            # Search for tool in built in directory
            try:
                module = importlib.import_module(builtin_tools_dir)
                tools.append(getattr(module, name))
                print(f"[Success] Found {name} in built-in tools directory!")
                found_in_builtin = True
            except:
                print(f"[Error] Cannot load {name}, it does not exist in built-in tools, looking in custom directory!")
            if found_in_builtin: continue

            # If tool was not found in built in directory then search in custom directory
            try:
                module = importlib.import_module(f"{custom_tools_dir}.{name}")
                tools.append(getattr(module, name))
                print(f"[Success] Found {name} in custom tools directory!")
            
            except:
                print(f"[Error] Cannot load {name}, it probably does not exist in custom tools directory.")
        print("Loader finished!")
        return tools

    

           
    def create_embedding(self):
        return AzureTextEmbedding(
        service_id="embedding_service",
        deployment_name=self.embedding_deploy_name,
        endpoint=self.embedding_endpoint,
        api_version=self.embedding_version,
        api_key=self.embedding_key
    )
        



    def filter_tools(self, all_mcp_tools):
        filter={"included_functions":[]}
        print('filters:',filter)
        tools = []
        all_tools = self.get_tools()
        print(f"all_tools :::: {all_tools}")
        
        for tool_name in all_tools:
            for tool in all_mcp_tools:
                if tool == tool_name:
                    tools.append(tool)
                    filter["included_functions"].append('tools-'+str(tool))
                    # print(f'Successfully imported {tool_name} from MCP Server')
        
        # tools_list=filter['included_functions']
        tools_list=filter
        settings=OpenAIPromptExecutionSettings(service_id=self.service_id, function_choice_behavior=FunctionChoiceBehavior.Auto(filters=self.filter))# type: ignore
        return tools_list
    
    def sk_messages_to_open_ai_messages(self, messages: List[Any], final_response : str) -> List[Dict[str, Any]]:
        """
        Convert Semantic Kernel `chat_history.messages` (typed objects) into OpenAI-compatible chat messages.

        Args:
            messages: List of ChatMessageContent objects (strongly typed)
            result : Final string output of the agent
        Returns:
            List of dicts in OpenAI chat message format.
        """
        openai_messages = []
        for msg in messages:
            role = msg.role.value
            content_pieces = []
            function_call= None

            for item in getattr(msg, "items", []):
                ctype = getattr(item, "content_type", None)

                if ctype == "text":
                    text = getattr(item, "text", None)
                    if text:
                        content_pieces.append(text)

                elif ctype == "function_call":
                    function_call = {
                        "name": getattr(item, "function_name", ""),
                        "arguments": getattr(item, "arguments", "{}")
                    }
                    content_pieces = [] 
                elif ctype == "function_result":
                    result = getattr(item, "result", None)
                    extracted_texts: List[str] = []

                    if isinstance(result, list):
                        for r in result:
                            text = None

                            if hasattr(r, "inner_content") and hasattr(r.inner_content, "text"):
                                text = r.inner_content.text
                            elif hasattr(r, "text"):
                                text = r.text

                            if text:
                                extracted_texts.append(text)

                    elif isinstance(result, str):
                        extracted_texts.append(result)
                    else:
                        extracted_texts.append(str(result))

                    if extracted_texts:
                        content_pieces.append("\n".join(extracted_texts))

            message_obj = {"role": role}

            if function_call:
                message_obj["content"] = None
                message_obj["function_call"] = function_call
            else:
                content_str = "\n".join(content_pieces) if content_pieces else ""
                message_obj["content"] = content_str

            openai_messages.append(message_obj)


        openai_messages.append(
            {
                'role' : 'assistant',
                'content' : final_response
            }
        )

        return openai_messages

    # Agent execution logic
    @observe(name="semantic_kernel_agent", capture_input=True, capture_output=True)
    async def execute_agent_node(self, state: AgentState, trace_session_id=None, traj_eval = False) -> AgentState:
        trace_metadata = {
                    "agent_name": self.config.get('agent_name'),
                    "instance_id": self.session_id,
                }
        response = 'agent not executed'
        finalResponse = ''
        custom_trace_id = self.config.get('instance_id').replace('-', '') if self.config.get('instance_id') else self.config.get('agent_name')
        with self.langfuse.start_as_current_span(name=trace_session_id, metadata=trace_metadata, trace_context={"trace_id": trace_session_id if trace_session_id else custom_trace_id}) as span:
            carrier: dict[str, str] = {}
            inject(carrier)
            headers={
                    "Authorization": self.mcp_auth,
                    **carrier
                }
            # If using approach 1 then generate the MCP server
            if self.mcp_approach == 1:
                # generate the server file
                generate_server_file(
                    output_filename="mcp_servers\\mcp_server.py",
                    server_name="Custom MCP server",
                    host="localhost",
                    port=8000,
                    transport="sse",
                    tool_names=validate_tools(self.get_tools())
                )
                # Run the generated server
                self.mcp_server_url = run_server("mcp_servers\\mcp_server.py")
            
            try:
                mongodb_store = MongoDBAtlasStore(
                    connection_string= self.db_url,
                    database_name=self.db_name
                )
            except Exception as e:
                print('failed connecting mongodb ..')
                return

            indexes_created = await self.ensure_atlas_indexes()
            if not indexes_created:
                print('::: index creation failed :::')
            try:
                collection = mongodb_store.get_collection(
                    record_type=self.Conversation,
                    collection_name="conversations"
                )
                
            except Exception as e:
                print('failed to initialize mongodb',e)
                return
            
            
            response = 'agent not executed'
            finalResponse = ''
            try:
                for i,v in enumerate(self.mcp_servers):
                    # async with MCPSsePlugin(name=f"tools_{i}",description=f"tools Plugin : {i}",url=v) as mcp_tools:
                    mcp_tools=MCPSsePlugin(name=f"tools_{i}",description=f"tools Plugin : {i}",url=v, headers=headers)
                    await mcp_tools.connect()
                    self.mcp_plu.append(mcp_tools)
                    self.kernel.add_plugin(mcp_tools)
                
                    print('plugins were:',mcp_tools)
                    match self.mcp_approach:
                        case 1:
                            print("Getting all tools from Custom MCP server (Approach 1)")
                            # self.tools = mcp_tools
                            print('*************************')
                            all_tools=[]
                            for plugin_name, plugin_instance in self.kernel.plugins.items():
                                print(f'Plugin: {plugin_name}')
                                for function_name, function in plugin_instance.functions.items():
                                        # print(f'Function: {function_name}')  
                                        all_tools.append(function_name) 
                            print('*************************')
                            print(all_tools)
                            self.tools=all_tools
                        case 2:
                            print("Getting all tools from MCP server (Approach 2)")
                            # self.tools = mcp_tools
                            print('*************************')
                            all_tools=[]
                            for plugin_name, plugin_instance in self.kernel.plugins.items():
                                print(f'Plugin: {plugin_name}')
                                for function_name, function in plugin_instance.functions.items():
                                        # print(f'Function: {function_name}')  
                                        all_tools.append(function_name) 
                            print('*************************')
                            print(all_tools)
                            self.tools=all_tools

                        case 3:
                            print("Getting select tools from MCP server (Approach 3)")
                            print('*************************')
                            all_tools=[]
                            '''
                            for plugin_name, plugin_instance in self.kernel.plugins.items():
                                print(f'Plugin: {plugin_name}')
                                for function_name, function in plugin_instance.functions.items():
                                        # print(f'Function: {function_name}')  
                                        all_tools.append(function_name) 
                            print('*************************')
                            print(all_tools)
                            '''
                            
                            print('ft:::',self.ft)
                            
                            name=mcp_tools.name
                            
                            for plugin_name, plugin_instance in self.kernel.plugins.items():
                                print(f'Plugin: {plugin_name}')
                                print('plugin instance:',plugin_instance)
                                for function_name, function in plugin_instance.functions.items():
                                    print(f'Function name::: {function_name}') 
                                    if function_name in self.ft:
                                        print('name:',name)
                                        self.filter["included_functions"].append(f"{name}-{function_name}")
                                        self.ft.remove(function_name)
                                        print('check filter:',self.filter)
                                        
                                    
                            print('filters:',self.filter)
                            settings=OpenAIPromptExecutionSettings(service_id=self.service_id, function_choice_behavior=FunctionChoiceBehavior.Auto(filters=self.filter))# type: ignore
        
                            
                            # all_mcp_tools = all_tools
                            # filter = self.filter_tools(all_mcp_tools)
                            self.tools=self.filter

                            print(f"mcp filtered tools :::: {self.tools}")
                        case _:
                            print('Please choose correct option')





                    q=state['input']
                    
                    try:
                        # Get context from external memory
                        self.memory_context = await self.external_memory_mongodb(q, collection, self.embedding_service)
                        
                        chat_history = ChatHistory()
                        chat_history.add_system_message(f"You are a helpful assistant. Here is relevant context from previous conversations:\n{self.memory_context}")
                        chat_history.add_user_message(q)
                        settings=AzureChatPromptExecutionSettings(service_id=self.service_id, max_tokens=1024, temperature=0.7, function_choice_behavior=FunctionChoiceBehavior.Auto(filters=self.filter))# type: ignore
                        # result=await kernel.invoke_prompt(q, settings=settings)    
                    
                        result = await self.chat_service.get_chat_message_content(
                            chat_history=chat_history,
                            settings=settings,
                            kernel=self.kernel
                            
                        )
                        
                        if traj_eval :
                            return self.sk_messages_to_open_ai_messages(chat_history.messages, result)
                    
                        # response=await self.kernel.invoke_prompt(q, settings=settings)                    
                        # print('Agents response:', response)
                        
                    
                        # ======
                        
                        if hasattr(result, 'content') and result.content is not None:
                            response = result.content
                        else:
                            response = str(result)
                            
                        print("Assistant:", response)
                            
                        # Store the conversation in memory
                        conv_text = f"User: {q} Assistant: {response}"
                        conv_embedding = await self.embedding_service.generate_embeddings([conv_text])
                        conv_vec = conv_embedding[0]
                            
                        if hasattr(conv_vec, 'ndim') and conv_vec.ndim > 1:
                            conv_vec = conv_vec.flatten().tolist()
                        elif hasattr(conv_vec, '__iter__') and not isinstance(conv_vec, list):
                            conv_vec = list(conv_vec)
                            
                    
                            
                            
                        record = self.Conversation(
                            id=f"conv_{int(time.time() * 1000)}",
                            session_id=self.session_id,
                            text=conv_text,                        
                            embedding=conv_vec  
                                    
                        )
                            
                        await collection.upsert(record)
                            
                            
                    except Exception as e:
                        print('Error :',e)    
                        # ======

                    
                    if response is not None:
                        finalResponse = response            
            except Exception as e:
                print(f"Error connecting to or using SSE MCP server (Managed): {e}")

        return finalResponse
                
        '''return {
            "input": state["input"],
            "history": state.get("history", []) + [response],
            "output": response
        }'''

    # interface method of Agent
    async def run(self, input: str, params=None, traj_eval=False, cancel_event: asyncio.Event = None,mcp_authorization=None, trace_session_id=None) -> Any:
        print(f"\n\n\n input in run ::: {input} \n\n\n")
        self.mcp_auth=mcp_authorization
        
        fixer = """Use proper markdown formatting strictly for display content. Do not apply any markdown formatting (e.g., backticks, asterisks) to file paths, dictionary keys, or values.

        When using a retrieval tool to display data:
        - Format the data in markdown for readability, but exclude file paths from markdown formatting.

        For function calls:
        - Include the function name if the function requires it.

        For image generation:
        - Return only a raw JSON object with no additional text, explanation, or formatting.

        For outputs that include file paths:
        - Ensure there is only one forward slash between directories.
    - Return a dictionary in the following format:

        {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt,
            "response": Markdown-based agent response summary
        }

    If the tool returns only:
        {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt
        }

    Then automatically append the "response" key with a markdown-formatted agent response summary, resulting in the four-key dictionary structure shown above.

    Do not wrap the dictionary output in markdown formatting. Do not include any extra text or symbols around the JSON.
    """
        input += fixer
        if params is not None:
            if params.get('file',''):
                input += "file path :"+params['file']
            if params.get('tools_id',''):
                input += "tools_id :"+params['tools_id']
        print("DEBUG",input)
        
        result = await self.execute_agent_node({"input": input}, trace_session_id=trace_session_id, traj_eval = traj_eval)
        print(f"result :::: {result}")
        print(result.__str__())
        return result.__str__()
