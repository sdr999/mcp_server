from azure.storage.fileshare import ShareDirectoryClient
from azure.storage.fileshare import ShareFileClient
import os
from dotenv import dotenv_values
from agentic_framework.utils import global_variables
import nest_asyncio
nest_asyncio.apply()

class AzureFileAdapter:
    def __init__(self):
        self.env=global_variables.env
        self.connection_string =self.env["AZURE_FILESTORE_CONNECTION_URL"]
        self.share_name = self.env["AZURE_FILESTORE_NAME"]

    def list_files(self, directory_path: str) -> list:
        dir_client = ShareDirectoryClient.from_connection_string(
            conn_str=self.connection_string,
            share_name=self.share_name,
            directory_path=directory_path
        )
        entries = []
        try:
            for item in dir_client.list_directories_and_files():
                entries.append({
                    "name":item["name"],
                    "is_directory": item["is_directory"]
                })
        except Exception as e:
            print("Exception listing dir:", e)
        return entries

    def read_file(self, file_path: str) -> str:
        """
        Read the contents of a file from Azure File Share.
 
        :param file_path: The full path to the file in the share.
        :return: The content of the file as a string.
        """
        file_client = ShareFileClient.from_connection_string(
            conn_str=self.connection_string,
            share_name=self.share_name,
            file_path=file_path
        )
 
        try:
            stream = file_client.download_file()
            data = stream.readall()
            return data.decode("utf-8")
        except Exception as e:
            raise RuntimeError(f"Failed to read file '{file_path}': {e}")
 
    def create_file(self, file_path: str, content) -> None:
        """
        Create a new file (or overwrite if exists) in Azure File Share.
 
        :param file_path: The full path in the share where the file will be created.
        :param content: The content to write into the file.
        """
        file_client = ShareFileClient.from_connection_string(
            conn_str=self.connection_string,
            share_name=self.share_name,
            file_path=file_path
        )
 
        try:
            # Create/overwrite the file with the specified length
            file_client.create_file(size=len(content))
 
            # Upload content to the file
            file_client.upload_file(content)
        except Exception as e:
            raise RuntimeError(f"Failed to create file '{file_path}': {e}")
        
    def read_file_bytes(self, file_path: str) -> bytes:
        """
        Read the binary content of a file from Azure File Share.
        """
        file_client = ShareFileClient.from_connection_string(
            conn_str=self.connection_string,
            share_name=self.share_name,
            file_path=file_path
        )
        print("data printing:: :: ::\n\n")
        stream = file_client.download_file()
        data = stream.readall()
        print("data:: :: :: \n\n\n",data)
        return  data
    
    def delete_file(self,file_path):
        try:
            file_client = ShareFileClient.from_connection_string(
            conn_str=self.connection_string,
            share_name=self.share_name,
            file_path=file_path
        )
            file_client.delete_file()
            return True
        except Exception as e:
            return "Error Deleting file"

