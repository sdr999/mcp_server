from crewai import LLM, Agent, Task, Crew, Process
#from crewai.tools import tool
from agentic_adapters.utils.mcp_server_generator import generate_server_file, run_server, validate_tools
import os
import json
from typing import Any
from typing import TypedDict
from agentic_adapters.core.base_agent import BaseAgent
import subprocess
import sys
import importlib
from crewai_tools import MCPServerAdapter
from crewai.utilities.converter import Converter
from agentic_framework.utils import global_variables

# Getting constants from properties.json
#base_dir = os.path.dirname(os.path.abspath(__file__))
#properties_dir = os.path.join(base_dir, "config", "properties.json")

#with open(properties_dir, "r") as f:
 #   data = json.load(f)


class AgentState(TypedDict):
    input: str
    history: list
    output: str


class CrewAIAgent():
    def __init__(self, config: dict):
        # init config details
        self.config = config
        # Create a method to load model properties like API keys and other prerequisites
        self.model_setup()

        # install required packages
        self.install_package()

        # install tools for agent as per config
        # self.tools = self.load_tools(self.get_tools())
        # installs tools dynamically
        self.tools = []

        # MCP Approach logic
        self.mcp_approach = 3
        self.mcp_server_url = global_variables.env["MCP_URL"]
        # load llm for agent to use
        self.llm = self.load_llm()

        # create prompts
        self.prompts = self.load_prompts()

        # Build the Crew AI agent
        self.agent = self.create_agent()

        # define the task for the agent
        # self.task = self.create_task()

        # create crew
        # self.crew = self.create_crew()

    # install pip packages
    def install_package(self, import_name=None):
        print(f"inside install_package:: {self.config}")
        if 'package_names' in self.config:
            package_names = self.config['package_names']
            packages = [pkg.strip() for pkg in package_names.split(",") if pkg.strip()]
            """
            Installs a package using pip if it isn't already installed.

            Args:
                package_name (str): The name used with pip to install the package.
                import_name (str): The name used to import the module (if different from package_name).
            """
            for package_name in packages:
                import_name = package_name
                try:
                    importlib.import_module(import_name)
                    print(f"'{import_name}' is already installed.")
                except ImportError:
                    print(f"'{import_name}' not found. Installing '{package_name}'...")
                    subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])

    # Model setup logic (NEEDS TO CHANGE TO ADAPT TO NEW MODEL_PROPERTIES CONFIG)
    def load_model_properties(self):
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            self.MODEL_NAME = model_additional_properties["MODEL_NAME"]
            self.APP_NAME = model_additional_properties["APP_NAME"]
            self.USER_ID = model_additional_properties["USER_ID"]
            self.SESSION_ID = model_additional_properties["SESSION_ID"]


        #Setting up environment variables as per Litellm requirements!
        for key in model['additional_properties']:
            os.environ[key] = model['additional_properties'][key]
        
        return
    def model_setup(self):
        #os.environ["MODEL_NAME"] = data["MODEL_NAME"]
        # loading api key, api base, api version
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            self.MODEL_NAME = model_additional_properties["MODEL_NAME"]
            self.APP_NAME = model_additional_properties["APP_NAME"]
            self.API_VERSION = model_additional_properties["AZURE_OPENAI_API_VERSION"]
            self.USER_ID = model_additional_properties["USER_ID"]
            self.SESSION_ID = model_additional_properties["SESSION_ID"]
        for key in model['additional_properties']:
            os.environ[key] = model['additional_properties'][key]

    # get list of tool names from configuration
    def get_tools(self) -> list:
        print(f"inside get_tools:: {self.config}\n")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        if tools is not None:
            for tool in tools:
                tools_name.append(tool['name'])   
        print(f"tools_name ::: {tools_name}")                 
        return tools_name

    # loads all required tools and returns a list of function tools
    def load_tools(self, tool_names) -> list:
        print(f"inside load tools: {tool_names}")
        builtin_tools_dir = "crewai_tools"
        custom_tools_dir = "agentic_adapters.adapter_crewai.tools"
        tools = []
        for name in tool_names:
            found_in_builtin = False
            # Search for tool in built in directory
            try:
                module = importlib.import_module(builtin_tools_dir)
                tools.append(getattr(module, name))
                print(f"[Success] Found {name} in built-in tools directory!")
                found_in_builtin = True
            except:
                print(f"[Error] Cannot load {name}, it does not exist in built-in tools, looking in custom directory!")
            if found_in_builtin: continue

            # If tool was not found in built in directory then search in custom directory
            try:
                module = importlib.import_module(f"{custom_tools_dir}.{name}")
                tools.append(getattr(module, name))
                print(f"[Success] Found {name} in custom tools directory!")
            except:
                print(f"[Error] Cannot load {name}, it probably does not exist in custom tools directory.")
        print("Loader finished!")
        return tools

    # Method to load LLM to use with agent
    def load_llm(self):
        # return LLM(model=os.environ["MODEL_NAME"])
        return LLM(model=self.MODEL_NAME,
                   api_version=self.API_VERSION
                   )

    # Method to load prompts
    def load_prompts(self):
        agent_details = self.config['agent']

        prompts = agent_details['prompts']
        print(f"prompts :::: {prompts}")
        description = None
        goal = None
        role = None
        backstory = None
        expected_output = None
        for prompt in prompts :
            prompt_type = prompt['prompt_type']
            if prompt_type == "description":
                description = prompt['message']               
            if prompt_type == "goal":
                goal = prompt['message'] 
            if prompt_type == "role":
                role = prompt['message']   
            if prompt_type == "backstory":
                backstory = prompt['message']                                     
            if prompt_type == "expected_output":
                expected_output = prompt['message']  
        return {
            "description": description,
            "goal": goal,
            "role": role,
            "backstory": backstory,
            "expected_output": expected_output
        }

    # Method to create agent
    def create_agent(self):
        return Agent(
            role=self.prompts["role"],
            goal=self.prompts["goal"],
            backstory=self.prompts["backstory"],
            llm=self.llm,
            tools=self.tools
        )

    # Method to create task
    def create_task(self, task_description):
        return Task(
            description=task_description,
            agent=self.agent,
            expected_output=self.prompts["expected_output"]
        )

    # Method to create agent runner
    def create_crew(self):
        return Crew(
            agents=[self.agent],
            tasks=[self.task],
            verbose=False,
            process=Process.sequential
        )

    def filter_tools(self, all_mcp_tools):
        tools = []
        all_tools = self.get_tools()
        print(f"all_tools :::: {all_tools}")
        for tool_name in all_tools:
            for tool in all_mcp_tools:
                if tool.name == tool_name:
                    tools.append(tool)
                    print(f'Successfully imported {tool_name} from MCP Server')
        print(f"tools from filtered tool :::: {tools}")
        return tools

    # Agent execution logic
    async def execute_agent_node(self, state: AgentState) -> AgentState:

        # If using approach 1 then generate the MCP server
        if self.mcp_approach == 1:
            # generate the server file
            generate_server_file(
                output_filename="mcp_servers\\mcp_server.py",
                server_name="Custom MCP server",
                host="localhost",
                port=8000,
                transport="sse",
                tool_names=validate_tools(self.get_tools())
            )
            # Run the generated server
            self.mcp_server_url = run_server("mcp_servers\\mcp_server.py")

        server_params = {
            "url": "http://10.20.0.61:8000/sse",
            "transport": "sse"
        }

        response = 'agent not executed'
        finalResponse = ''
        try:
            with MCPServerAdapter(server_params) as mcp_tools:
                match self.mcp_approach:
                    case 1:
                        print("Getting all tools from Custom MCP server (Approach 1)")
                        self.tools = mcp_tools
                        all_tools = [tool.name for tool in mcp_tools]
                        print(all_tools)
                    case 2:
                        print("Getting all tools from MCP server (Approach 2)")
                        self.tools = mcp_tools
                        all_tools = [tool.name for tool in mcp_tools]
                        print(all_tools)

                    case 3:
                        print("Getting select tools from MCP server (Approach 3)")
                        all_mcp_tools = mcp_tools
                        self.tools = self.filter_tools(all_mcp_tools)
                        print(f"mcp filtered tools :::: {self.tools}")
                    case _:
                        print('Please choose correct option')


                self.agent.tools = self.tools

                self.task = self.create_task(state["input"])
                self.crew = self.create_crew()
                response = self.crew.kickoff()
                print('Agents response:', response)

                
                if response is not None:
                    finalResponse = response            
        except Exception as e:
            print(f"Error connecting to or using SSE MCP server (Managed): {e}")

        return finalResponse            
        '''return {
            "input": state["input"],
            "history": state.get("history", []) + [response],
            "output": response
        }'''

    # interface method of Agent
    async def run(self, input: str, params=None) -> Any:
        print(f"\n\n\n input in run ::: {input} \n\n\n")
        fixer = "Use proper markdown formatting. If using some retrieval tool to display data ensure markdown format WITHOUT FAIL. For self argument use function name if required by the function, In case of image generation, return only the json output with no other message. Ensure in case of filepath there are no more than one slash"                 
        input += fixer
        if params is not None:
            if params.get('file',''):
                input += "file path :"+params['file']
            if params.get('tools_id',''):
                input += "tools_id :"+params['tools_id']
        print("DEBUG",input)
        result = await self.execute_agent_node({"input": input})
        print(f"result :::: {result}")
        print(result.__str__())
        return result.__str__()

