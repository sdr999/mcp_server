from crewai.tools import tool
@tool("search_tool")
def search_tool(input: str)->str:
	"""Search tool for GoogleADK"""
	return 'CrewAI Search Tool testing'