from crewai.tools import tool
@tool("color_tool")
def color_tool(input: str)->str:
	"""Returns color of things"""
	color = {"hypercube":"scarlet red", "obsidian":"black"}
	return f"{input} is {color[input]}!"