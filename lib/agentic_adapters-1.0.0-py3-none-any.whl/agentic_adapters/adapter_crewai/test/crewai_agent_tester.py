import sys
import os

sys.path.append(os.path.abspath(os.path.join(__file__, "..", "..", "..", "..")))

from agentic_framework.core.agent import Agent

agent_config = {
    "type":"crewai",
    "package_names":"crewai,litellm",
    "agent_name":"HelperAgent", 
    "description":"Assist user with their query",
    "goal":"You will help user with their queries. You have a set of tools use them appropriately and help the user. You different tools as per query requirements",
    "backstory":"A smart helper agent",
    "role":"A helper agent that uses a set of tools to assist the user",
    "expected_output":"Result of user query",
    "tool_names":"SerperDevTool, nonexistent_tool, search_tool, color_tool, get_weather",
    "mcp_server_url":"http://localhost:8000/sse",
    "mcp_approach":3
    }



ADKAgent = Agent(agent_config)

print("Successfully created Agent")
data = ADKAgent.run("Whats the weather in new york? Also what color is a hypercube?")

for key in data:
    print(key+":", data[key])