# from langgraph.graph import StateGraph, END
# from agentic_framework.core.agent import Factory
# #from langgraph_agent import custom_agent_node
# from adapter_agno.agno_agent import AgentState
# from adapter_agno.agno_agent import LangchainAgent
import os, sys
from pathlib import Path
import json
sys.path.append(str(Path(__file__).parent.parent.parent))
from adapter_agno.agno_agent import AgentState, agnoAgent
from agentic_framework.factory.agent_factory import AgentFactory
from agentic_framework.core.agent import Agent


# Example usage
if __name__ == "__main__":
    
    config={
        "system_prompt":[
            "You are a assitant, who search for information"
        ],
        #"tool_names":"duckduckgo",
        #"instructions": ["Be concice."]
        #"tool_name": "search_tool_agno"
        #"tool_name":"stackexchange",
        #"package_name":"wikipedia"
        "package_name": "google-search-results"
    }
    obj1 = agnoAgent(config)
    # print("\n\n\n")
    # print(type(obj1))
    # print(dir(obj1))
    # print("\n\n\n")
    #response = obj1.run("Who is the CEO of Tesla?", config)
    response = obj1.run("Who is the CEO of Tesla?", config)
    #response = obj1.run({"input": "What is Google's stock?"}, config)
    print(response)
    # print(response['output'])
    # print(response['output']['output'])