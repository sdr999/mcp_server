import os, sys
from pathlib import Path
import json
sys.path.append(str(Path(__file__).parent.parent.parent))

#from agentic_adapters.adapter_agno.agno_tool_generator import agnoToolGenerator
from adapter_agno.agno_tool_generator import agnoToolGenerator

def test_generate_tool():

    print("test_generate_tool")
    
    test_dir = os.path.dirname(os.path.abspath(__file__))
    data_file_path = os.path.join(test_dir, "data", "test-tool-data.json")  
    with open(data_file_path) as f:
        data = json.load(f)
    tool_generator = agnoToolGenerator()
    tool_generator.generate(data)


if __name__ == "__main__":
    test_generate_tool()
 