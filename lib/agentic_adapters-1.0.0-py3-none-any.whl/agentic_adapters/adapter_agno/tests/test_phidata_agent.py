#from langgraph.graph import StateGraph, END
#from agent_factory import Factory
#from langgraph_agent import custom_agent_node
#from adapter_langgraph.langgraph_agent import AgentState
#from adapter_langgraph.langgraph_agent import LangchainAgent
import os, sys
from pathlib import Path
import json
sys.path.append(str(Path(__file__).parent.parent.parent))
from adapter_agno.agno_agent import AgentState, agnoAgent
from agentic_framework.factory.agent_factory import AgentFactory
from agentic_framework.core.agent import Agent
from agent_factory import Factory
# Example usage
if __name__ == "__main__":
    
    config={
        "system_prompt":[
            "You are a assitant, who search for information"
        ],
        #"tool_names":"wikipedia",
        #"tool_name":"stackexchange",
        #"package_name":"wikipedia",
        "type" : "agno",
        "package_name": "google-search-results"
    }
    #obj = Agent(config)
    #print(obj)

    obj1 = Factory.create_instance("adapter_langgraph.langgraph_agent.LangchainAgent", config)
 
    response = obj1.run({"Who is the CEO of Tesla?"}, config) 
 
    #print(obj.run("Who is the CEO of Tesla?",config))
    #obj1 = AgentFactory.get_instance("adapter_agno.agno_agent.agnoAgent", config)
    # print("\n\n\n")
    # print(type(obj1))
    # print(dir(obj1))
    # print("\n\n\n")
    #response = obj1.run({"input": "Who is the CEO of Tesla?"}, config)
    #response = obj1.run({"input": "What is Google's stock?"}, config)
    #print(response)
    # print(response['output'])
    # print(response['output']['output'])