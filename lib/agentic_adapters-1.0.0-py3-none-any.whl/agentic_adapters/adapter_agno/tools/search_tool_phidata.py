from langchain.tools import tool

@tool
def search(query: str) -> str: 
   """Look up things online.""" 
     return "agno"