from agentic_adapters.core.base_agent import BaseAgent
from agentic_adapters.utils.mcp_server_generator import generate_server_file, run_server, validate_tools
# from phi.agent import Agent
# from phi.model.azure import AzureOpenAIChat
from langchain import hub
#from jproperties import Properties
from pathlib import Path
# import phi
# from phi.tools import Toolkit
# from phi.tools.tool import Tool
from mcp.client.session import ClientSession
from mcp.client.sse import sse_client
# from phi.utils.log import logger
import asyncio
import importlib
from typing import Any, Dict, List, Optional, TypedDict
import os,sys
import subprocess
from agno.agent import Agent
from agno.models.azure import AzureOpenAI
from agno.tools.mcp import MCPTools
from textwrap import dedent
#import nest_asyncio
from agentic_adapters.core.base_agent import BaseAgent
# from agentic_adapters.utils.mcp_server_generator import generate_server_file, run_server, validate_tools
#from jproperties import Properties
from pathlib import Path
from agentic_framework.utils import global_variables
import json
import inspect
#nest_asyncio.apply()
from agno.storage.mongodb import MongoDbStorage
from agno.memory.v2.db.mongodb import MongoMemoryDb
from agno.memory.v2.memory import Memory
from agno.tools.mcp import MCPTools,MultiMCPTools
from contextlib import AsyncExitStack
from agno.tools.mcp import SSEClientParams
from langfuse import Langfuse
import openlit 
from opentelemetry.propagate import inject

class AgentState(TypedDict):
    input: str
    history: list
    output: str
 
class CustomCallbackHandler():
    _after_model_func:str =None
    _before_model_func:str=None
    _after_tool_func:str=None
    _before_tool_func:str=None
    model_function = None
    tools_function = None

    def __init__(self,functions:Any):
        if functions is not None:
            self.model_function=functions["model"]
            self.tools_function=functions["tools"]
            self._before_model_func=self.model_function["before"]
            self._after_model_func=self.model_function["after"]
    # Tool Start
    def before_tool_call(self,tool_name):
        try:
            if self.tools_function is not None:
                self._before_tool_func=self.tools_function[tool_name]["before"]
                if self._before_tool_func is not None:
                    exec(self._before_tool_func,{"self": self})
        except Exception as e:
            
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # Tool End
    def after_tool_call(self,tool_name):
        try:
            if self.tools_function is not None:
                self._after_tool_func=self.tools_function[tool_name]["after"]
                if self._after_tool_func is not None:
                    exec(self._after_tool_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # LLM Start
    def before_model_call(self):
        try:
            if self.model_function is not None:
                if self._before_model_func is not None:
                    exec(self._before_model_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
 
    # LLM End
    def after_model_call(self):
        try:
            if self.model_function is not None:
                if self._after_model_func is not None:
                    exec(self._after_model_func,{"self": self})
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")


##Class to intercept the aresponse fucntion of the model to apply hooks
class HookedAzureOpenAI(AzureOpenAI):

    def __init__(self,before_model_call:callable = None , after_model_call:callable=None,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.before_model_call=before_model_call
        self.after_model_call=after_model_call
    async def aresponse(self, *args, **kwargs):
        if self.before_model_call is not None:
            if inspect.iscoroutinefunction(self.before_model_call):
                await self.before_model_call()
            else:
                self.before_model_call()

        #Running main aresponse from parent class
        result = await super().aresponse(*args, **kwargs)

        if self.after_model_call is not None:
            if inspect.iscoroutinefunction(self.after_model_call):
                await self.after_model_call()
            else:
                self.after_model_call()
        return result


class AgnoAgent(BaseAgent):
 
    def __init__(self, config: dict):
        self.config = config
        self.langfuse_public_key=global_variables.env['LANGFUSE_PUBLIC_KEY']
        self.langfuse_secret_key=global_variables.env['LANGFUSE_SECRET_KEY']
        self.langfuse_host=global_variables.env['LANGFUSE_HOST']
        self.langfuse = Langfuse(
            secret_key=self.langfuse_secret_key,
            public_key=self.langfuse_public_key,
            host=self.langfuse_host
           )
        openlit.init(tracer=self.langfuse._otel_tracer,event_logger=True, application_name=self.config["agent"].get("name"))
        
        functions=self.config["callback_functions"]
            
        self.custom_callback_handler=CustomCallbackHandler(functions)
        # self.mcp_approach = config.get("mcp_approach", 3)
        self.mcp_approach=3
        self.server_url=global_variables.env["MCP_URL"]
        self.mcp_servers=self.config["mcp_servers"]
        self.mcp_auth=self.config["mcp_authorization"]
        if "connector_description" in self.config:
            self.connector_config=self.config["connector_description"]
        else:
            self.connector_config=None
        self.tools = []
        self.not_found_tools=[]
        self.llm = self.load_llm()
        # self.instructions = self.load_instructions()
        self.prompts=self.load_prompts()
        self.agent = None  
        # Will be initialized once tools are loaded
        self.db_url=f'mongodb://{global_variables.env["MONGO_DB_HOST"]}:{global_variables.env["MONGO_DB_PORT"]}/' 
        self.db_name=global_variables.env["MONGO_DB_NAME"]
        # Create a storage backend using the Mongo database
        self.storage = None
        self.agent_name=self.config["agent"].get("name")
        self.instance_id=self.config.get("instance_id") or self.agent_name
        self.memory_type=self.config.get("memory_type") or "external"
        if self.memory_type == "external":
            self.storage = MongoDbStorage(
            # store sessions in the agent_sessions collection
            db_name=self.db_name,
            collection_name="agent_sessions",
            db_url=self.db_url,
            )


 
 
    # def load_llm(self):
    #     model_info = self.config["models"][0]
    #     props = model_info["additional_properties"]
    #     return AzureOpenAI(
    #     id="azure-openai",
    #     api_key=props["AZURE_OPENAI_API_KEY"],
    #     azure_endpoint=props["AZURE_OPENAI_ENDPOINT"],
    #     azure_deployment=props["AZURE_OPENAI_DEPLOYMENT_NAME"],
    #     temperature=int(props.get("temperature", 0))
    #     )
    def set_connector_description(self,toolsets):
        if self.connector_config["REST"]:
            for tool in toolsets:
                if getattr(tool, 'name', None) == "rest_connector":
                    tool.description = self.connector_config["REST"]
        return toolsets 
 
    def load_llm(self) -> Any:
            print(f"inside load_llm:: {self.config['models']}")
            model_additional_properties = None
            for model in self.config['models']:
                model_additional_properties = model['additional_properties']
            print(f"model additional_properties :::: {model_additional_properties}")
            if model_additional_properties is not None:
                azure_openAI_chat =  HookedAzureOpenAI(
                                    before_model_call=self.custom_callback_handler.before_model_call,
                                    after_model_call=self.custom_callback_handler.after_model_call,
                                    id="azure-openai",
                                    api_key=model_additional_properties['AZURE_OPENAI_API_KEY'],
                                    azure_endpoint=model_additional_properties['AZURE_OPENAI_ENDPOINT'],
                                    azure_deployment=model_additional_properties['AZURE_OPENAI_DEPLOYMENT_NAME'],
                                    api_version=model_additional_properties['AZURE_OPENAI_API_VERSION'],
                                    temperature=int(model_additional_properties['temperature'])
                        )
                return azure_openAI_chat
 
 
#this will get all the required tools
    def get_tools(self) -> list:
        print(f"inside get_tools:: {self.config}")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        if tools is not None:
            for tool in tools:
                tools_name.append(tool['name'])
        print(f"tools_name ::: {tools_name}")
        return tools_name
 
 
#this will load the react prompt
    def load_prompts(self) -> Any:
        print(f"inside load_prompts:: {self.config}")
        agent_details = self.config['agent']
       
        prompts = agent_details['prompts']
        print(f"prompts :::: {prompts}")
        # Get the ReAct prompt from LangChain hub
        # prompt = hub.pull("hwchase17/react")
        system_prompts = []
        for prompt in prompts :
                    prompt_type = prompt['prompt_type']
                    if prompt_type == "system_prompts":
                        message = prompt['message']
                        system_prompts.append(message)
        system_prompt=""
        for msgs in system_prompts:
            system_prompt = system_prompt + ". \n" + msgs
        # Modify the pulled prompt by prepending your system message
        # prompt.template = system_prompt + "\n\n" + prompt.template
        # print(prompt)
        return system_prompt
 
 
    # def load_instructions(self):
    #     system_prompt = ""
    #     prompts = self.config["agent"]["prompts"]
    #     for prompt in prompts:
    #         if prompt["prompt-type"] == "system_prompts":
    #             system_prompt += "\n" + prompt["message"]
    #     return dedent(system_prompt.strip())
 
 
    def load_tools(self):
        tool_names = self.get_tools()
        not_found_tools = []
        final_tools = []
        package_details = {
        'ArxivTools': 'arxiv_toolkit',  # from agno.tools.arxiv_toolkit import ArxivTools
        'BaiduSearchTools': 'baidusearch',
        'DuckDuckGoTools': 'duckduckgo',  # from agno.tools.duckduckgo import DuckDuckGoTools
        'ExaTools': 'exa',  # from agno.tools.exa import ExaTools
        'GoogleSearchTools': 'googlesearch',  # from agno.tools.googlesearch import GoogleSearchTools
        'HackerNewsTools': 'hackernews',
        'PubmedTools': 'pubmed',
        'SearxngTools': 'searxng',
        'SerpApiTools': 'serpapi_tools',
        'TavilyTools': 'tavily',
        'WikipediaTools': 'wikipedia',
       
        # Social
        'DiscordTools': 'discord_tools',
        'EmailTools': 'email',
        'GmailTools': 'gmail',
        'SlackTools': 'slack',
        'TelegramTools': 'telegram',
        'TwilioTools': 'twilio',
        'WhatsAppTools': 'whatsapp',
        'WebexTools': 'webex',
        'TwitterTools': 'x',  # X (formerly Twitter)
        'ZoomTools': 'zoom',
       
        # Web Scraping
        'AgentQLTools': 'agentql',
        'BrowserBaseTools': 'browserbase',
        'Crawl4aiTools': 'crawl4ai_tools',
        'JinaReaderTools': 'jina_reader',
        'NewspaperTools': 'newspaper_tools',
        'Newspaper4kTools': 'newspaper4k',
        'WebsiteTools': 'website',
        'FirecrawlTools': 'firecrawl',
        'SpiderTools': 'spider',  # from agno.tools.spider import SpiderTools
       
        # Data
        'CsvTools': 'csv_tools',
        'DuckDbTools': 'duckdb',
        'PandasTools': 'pandas',
        'PostgresTools': 'postgres',
        'SQLTools': 'sql',
        'ZepTools': 'zep',
       
        # Local
        'Calculator': 'calculator',
        'DockerTools': 'docker',
        'FileTools': 'file',
        'PythonTools': 'python',
        'ShellTools': 'shell',
        'Sleep': 'sleep',
       
        # Models
        'GroqTools': 'groq',
       
        # Additional
        'AirflowTools': 'airflow',
        'ApifyTools': 'apify',
        'AWSLambdaTools': 'aws_lambda',
        'CalComTools': 'calcom',
        'CartesiaTools': 'cartesia',
        'ComposioTools': 'composio',
        'ConfluenceTools': 'confluence',
        'CustomAPITools': 'custom_api',
        'DalleTools': 'dalle',
        'ElevenLabsTools': 'eleven_labs_tools',
        'E2BTools': 'e2b',
        'FalTools': 'fal_tools',
        'FinancialDatasetsTools': 'financial_datasets',
        'GiphyTools': 'giphy',
        'GithubTools': 'github',
        'GoogleMapsTools': 'google_maps',
        'GoogleCalendarTools': 'googlecalendar',
        'GoogleSheetsTools': 'google_sheets',
        'JiraTools': 'jira_tools',
        'LinearTools': 'linear_tools',
        'LumaLabsTools': 'lumalabs',
        'MLXTranscribeTools': 'mlx_transcribe',
        'ModelsLabsTools': 'models_labs',
        'OpenBBTools': 'openbb_tools',
        'OpenweatherTools': 'openweather',
        'ReplicateTools': 'replicate',
        'ResendTools': 'resend_tools',
        'TodoistTools': 'todoist',
        'YFinanceTools': 'yfinance',
        'YouTubeTools': 'youtube_tools',
        'ZendeskTools': 'zendesk',
        }
        
        print("tools names", tool_names)
        for tool_name in tool_names:
            pkg = package_details.get(tool_name)
            try:
                print(f"Trying builtin tool: agno.tools.{pkg}")
                module = importlib.import_module(f"agno.tools.{pkg.lower()}")
                tool_class = getattr(module, tool_name)
                final_tools.append(tool_class())
                print(f"[success] built-in tool: {tool_name} from agno.tools.{pkg}")
            except Exception as e:
                print(f"Custom tool not found: {e}. Adding to not_found_tools")
                not_found_tools.append(tool_name)

        self.not_found_tools = not_found_tools
        self.tools = final_tools
        return final_tools
##Hooks to atatch to before and after tools execution 
    async def logger_hook(self,function_name:str,function_call:callable,arguments:Dict[str,Any]):
        
        self.custom_callback_handler.before_tool_call(function_name)
        if inspect.iscoroutinefunction(function_call):
             
            res=await function_call(**arguments)
        else:
            res= function_call(**arguments)

        self.custom_callback_handler.after_tool_call(function_name)
        return res 
 
    def create_agent(self):
           
            print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
            print(self.tools)
            print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")

            self.agent = Agent(
                name=self.agent_name,
                model=self.llm,
                user_id=self.agent_name,
                tools=self.tools,
                description=self.prompts,
                instructions=dedent("""\
                You are a helpful assistant with access to utility tools:
               
                Note: Some tools may be filtered out based on the current configuration.
                Use the available tools to help users with their requests.
            """),
                show_tool_calls=True,
                markdown=True,
                tool_hooks=[self.logger_hook],
                add_history_to_messages=True,
                num_history_runs=20,
                storage=self.storage
            )

    async def run(self, input: str, params=None, traj_eval=False, cancel_event: asyncio.Event = None,mcp_authorization=None, trace_session_id=None) -> Any:
        self.mcp_auth=mcp_authorization
        self.load_tools()

        if self.mcp_approach != 3:
            self.not_found_tools = None
        server_params_list=[]

        trace_metadata = {
                    "agent_name" : self.config.get('agent_name'),
                    "instance_id": self.config.get('instance_id'),
                }
        custom_trace_id = self.config.get('instance_id').replace('-', '') if self.config.get('instance_id') else self.config.get('agent_name')
        
        with self.langfuse.start_as_current_span(name=trace_session_id, metadata=trace_metadata, trace_context={"trace_id": trace_session_id if trace_session_id else custom_trace_id}) as span:
        
            carrier: dict[str, str] = {}
            inject(carrier)
            print(f"\n\n\n\n+++++++++++++++ Carrier: {carrier}++++++++++++++\n\n\n")
            headers={
                "Authorization":self.mcp_auth,
                **carrier
            }

            for url in self.mcp_servers:
                server_params_list.append(SSEClientParams(url=url,headers=headers))

            print(self.not_found_tools)
            async with AsyncExitStack() as stack:
                self.tools = []

                # Keep MCP servers alive during the whole run

                mcp_tools = MultiMCPTools(
                    server_params_list=server_params_list,
                    include_tools=self.not_found_tools,
                    timeout_seconds=20,
                )
                await stack.enter_async_context(mcp_tools)
                self.tools.append(mcp_tools)

                if self.connector_config:
                    self.tools=self.set_connector_description(toolsets=self.tools)
                    # Debug: show what tools we got from each server

                if not self.agent:
                    self.create_agent()
                else:
                    self.agent.tools = self.tools 
                print(f"[Agno Agent] Executing prompt: {input}")

                # Agent execution instructions
                fixer = """Use proper markdown formatting strictly for display content. Do not apply any markdown formatting (e.g., backticks, asterisks) to file paths, dictionary keys, or values.

        When using a retrieval tool to display data:
        - Format the data in markdown for readability, but exclude file paths from markdown formatting.

        For function calls:
        - Include the function name if the function requires it.

        For image generation:
        - Return only a raw JSON object with no additional text, explanation, or formatting.

        For outputs that include file paths:
        - Ensure there is only one forward slash between directories.
        - Return a dictionary in the following format:

            {
                "file_name": file_name,
                "file_path": file_path,
                "prompt": prompt,
                "response": Markdown-based agent response summary
            }

        If the tool returns only:
            {
                "file_name": file_name,
                "file_path": file_path,
                "prompt": prompt
            }

        Then automatically append the "response" key with a markdown-formatted agent response summary, resulting in the four-key dictionary structure shown above.

        Do not wrap the dictionary output in markdown formatting. Do not include any extra text or symbols around the JSON.
        """
                input += fixer

                if params is not None:
                    if params.get("file", ""):
                        input += " file path :" + params["file"]
                    if params.get("tools_id", ""):
                        input += " tools_id :" + params["tools_id"]

                print("DEBUG", input)

                # Handle memory and run agent with cancellation 
                try:
                    if self.memory_type == "external":
                        task = asyncio.create_task(
                            self.agent.arun(input, session_id=self.instance_id)
                        )
                    else:
                        task = asyncio.create_task(self.agent.arun(input))

                    # Polling loop to support cancellation
                    while not task.done():
                        await asyncio.sleep(0.2)
                        if cancel_event and cancel_event.is_set():
                            task.cancel()
                            print("[CANCEL] Agno Agent execution cancelled.")
                            raise asyncio.CancelledError("Agno Agent execution cancelled by user.")

                    response = await task

                except asyncio.CancelledError as ce:
                    return {"status": "cancelled", "message": "agent terminated"}
                except Exception as e:
                    print(f"[ERROR] Agno Agent execution failed: {e}")
                    return {"status": "failure", "message": str(e)}

                # Return result 
                if traj_eval:
                    trajectory = self.get_agno_trajectory(response.messages)
                    return trajectory

                result = response.content
                result = result.strip("`")
                result = result.strip("json")
                return result


        
    def get_agno_trajectory(
        self,
        messages : Any
    ) -> List[Dict[str, Any]]:
        openai_msgs = []
        

        # Step 2: Iterate through intermediate steps
        for msg in messages:

            print(msg)
            
            role = msg.role
            content = msg.content or ""

            if role.lower() in ('system', 'user') or (role == 'assistant' and msg.tool_calls == None): 
                openai_msgs.append(
                    {
                        'role' : role,
                        'content' : content
                    }
                )

            elif role == 'assistant' and msg.tool_calls is not None: 

                tool_call_list = []
                for tool_call in msg.tool_calls :
                    tool_call_list.append(
                        {
                            "function": {
                                "name": tool_call['function']['name'],
                                "arguments": tool_call['function']['arguments']
                            }
                        }
                    )

                openai_msgs.append({
                    'role' : role,
                    'content' : content,
                    'tool_calls' : tool_call_list
                })
                
            elif role == 'tool' : 
                openai_msgs.append({
                    'role' : role,
                    'content' : content,
                    'name' : msg.tool_name
                })
            # Extract function name from tool (could sanitize if needed)
            
        return openai_msgs