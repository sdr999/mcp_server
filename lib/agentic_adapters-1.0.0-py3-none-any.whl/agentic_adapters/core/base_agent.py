from abc import ABC, abstractmethod
from typing import Any

class BaseAgent(ABC):
    def __init__(self, config: dict):
        self.config = config

    @abstractmethod
    def run(input: str, context=None) -> Any:
        raise NotImplementedError("Subclasses should implement this!")