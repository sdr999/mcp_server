from abc import ABC, abstractmethod


class BaseToolGenerator(ABC):

    @abstractmethod
    def generate(self, tool_config: dict):
        pass