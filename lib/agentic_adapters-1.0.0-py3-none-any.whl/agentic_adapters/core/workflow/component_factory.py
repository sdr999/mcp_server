from agentic_adapters.core.workflow.components.agent_node import AgentNode
from agentic_adapters.core.workflow.components.dummy_node import DummyNode
from agentic_adapters.core.workflow.components.agentic_router import AgenticRouter
from agentic_adapters.core.workflow.components.file_trigger import FileTrigger
from agentic_adapters.core.workflow.components.base.component import Component
from agentic_adapters.core.workflow.components.input_trigger import InputTrigger
from agentic_adapters.core.workflow.components.scheduled_trigger import ScheduledTrigger
from agentic_adapters.core.workflow.components.chat_input import ChatInput
from agentic_adapters.core.workflow.components.instant_trigger import InstantTrigger
from agentic_adapters.core.workflow.components.azure_file_input import AzureFileInput
from agentic_adapters.core.workflow.components.conditional_agentic_router import ConditionalAgenticRouter
from agentic_adapters.core.workflow.components.function_node import FunctionNode
from agentic_adapters.core.workflow.components.if_else_router import IfElseRouter
from agentic_adapters.core.workflow.components.switch_node import SwitchNode
from agentic_adapters.core.workflow.components.json_input import JsonInput

class ComponentFactory():
    """Responsible for creating components based on workflow schema"""
    
    #Defines the mapping of the components based on their name
    component_map = {
            "AgentNode" : AgentNode,
            "agent": AgentNode,
            "DummyNode": DummyNode,
            "AgenticRouter": AgenticRouter,
            "agentrouter": AgenticRouter,
            "conditionalrouter": ConditionalAgenticRouter,
            "FileTrigger": FileTrigger,
            "InputTrigger": InputTrigger,
            "ScheduledTrigger": ScheduledTrigger,
            "ChatInput": ChatInput,
            "InstantTrigger": InstantTrigger,
            "AzureFileInput": AzureFileInput,
            "IfElseRouter": IfElseRouter,
            "FunctionNode": FunctionNode,
            "function": FunctionNode,
            "SwitchNode": SwitchNode,
            "JsonInput": JsonInput
        }
    
    @classmethod
    def create_component(cls, component_type: str, config=None) -> Component:
        """Creates a component based on given type and configuration"""
        
        print(f"[DEBUG] Created component of type: {component_type}")
        #If config was passed create configured component
        if config is not None:
            return cls.component_map[component_type](config)

        #Returns component with default configuration
        return cls.component_map[component_type]()