import networkx as nx
import inspect
from agentic_adapters.core.workflow.component_factory import ComponentFactory
from agentic_adapters.core.workflow.components.base.component import Component
from agentic_adapters.core.workflow.components.base.router import Router
from agentic_adapters.core.workflow.components.base.input import Input
from agentic_adapters.core.workflow.components.base.trigger import Trigger
from langgraph.graph import StateGraph, END
from typing import TypedDict
from langfuse import Langfuse
from agentic_framework.utils import global_variables
class State(TypedDict):
    """Custom state to be used for workflow graph"""
    input: str
    file_data: str
    generated_output: str
    history: list
    output: str
    human_feedback_required: bool
    invocation_details: list

class Graph():
    """Base class for workflow StateGraph"""
    def __init__(self):
        self.graph = None
        self.trigger_component = None
        self.component_map = None
        
    def build_graph(self, workflow_schema: dict):
        """Build the graph from workflow schema"""
        pass

    async def invoke(self, state: dict):
        """Graph execution logic"""
        pass

class NetworkXStateGraph(Graph):
    """A networkx based stategraph for use with agentic workflows"""

    def __init__(self):
        #The Directed graph to be used for workflow execution
        self.graph = nx.DiGraph()

        #Path map for router {router: {path: destination_node}}
        self.router_paths = {}

        #A map for deciding which nodes to trigger based on router decision
        self.router_decisions = {}

        #Map of components
        self.component_map = {}

        #Map name of components
        self.node_names = {}
        
        #Set trigger component
        self.trigger_component = None
        
        # Langfuse env
        self.langfuse_public_key=global_variables.env['LANGFUSE_PUBLIC_KEY']
        self.langfuse_secret_key=global_variables.env['LANGFUSE_SECRET_KEY']
        self.langfuse_host=global_variables.env['LANGFUSE_HOST']
        self.langfuse = Langfuse(
            secret_key=self.langfuse_secret_key,
            public_key=self.langfuse_public_key,
            host=self.langfuse_host
           )
    

    def build_graph(self, workflow_schema: dict):
        """Build graph from workflow schema"""
        #Get nodes and edges from schema
        nodes = workflow_schema.get("data", {}).get("nodes", {})
        edges = workflow_schema.get("data", {}).get("edges", {})

        #maintain data for existing agents
        existing_agents = {}

        #Populate the component_map
        for node in nodes:  
            #Extract node details
            node_id = node.get("id")
            node_name = node.get("name")
            node_type = node.get("type")
            node_config = node.get("config", None)
            
            #Map node name to id
            self.node_names[node_id] = node_name
            
            #Add node to graph
            self.graph.add_node(node_id, is_starting_node = False)
            
            #Create component from component factory
            
            if node_type in ["agent", "AgentNode"]:
                #If agent is reused use existing instance rather than creating new one
                if existing_agents.get(node_config.get("id")):
                    print("Reusing AGENT INSTANCE::::")
                    component = self.component_map[existing_agents.get(node_config.get("id"))]
                #Else create compoenent and store details in existing agents
                else:
                    #Map agent id to node_id
                    print("Creating new AGENT INSTANCE::::")
                    existing_agents[node_config.get("id")] = node_id
                    component = ComponentFactory.create_component(node_type, node_config)
            
            else:
                component = ComponentFactory.create_component(node_type, node_config)
                
            self.component_map[node_id] = component

            #Set trigger component if identified
            if isinstance(component, Trigger):
                if not self.trigger_component: self.trigger_component = component
                else: raise ValueError("Multiple trigger components detected! Exiting...")       

        #Add edges to the graph
        for edge in edges:
            source = edge.get("source")
            destination = edge.get("destination")
            route = edge.get("route", None)
            
            #If node is a router component set up path mapping [possible only if source is a Router]
            if route is not None:
                #Set destination for given path in router path-map
                self.router_paths.setdefault(source, {})[route] = destination

            self.graph.add_edge(source, destination)

    async def invoke(self, state, skip_rule = None, human_feedback=None, session_id=None, session_class=None, repository=None, user_info=None,instance_id=None)->State:
        """Graph execution logic"""
        
        def _get_predecessor(node):
            """Helper function that returns the predecssor node that lead to current node"""
            pred_node = None

            #If node is first node in execution order then return __start__
            if self.graph.nodes[node]["is_starting_node"]:
                return "__start__"
            
            for pred in self.graph.predecessors(node):
                if pred in visited:
                    return pred
            
            #If no visited predecessor was found returns None
            return pred_node

        def _should_skip_node(node):
            """Decided whether execution of given node should be skipped or not"""

            #Get predecessor
            pred_node = _get_predecessor(node)
            
            #Skip node if no predecessor was visited
            if pred_node is None:
                print(f"Skipping {node}, REASON: No predecessor visited")
                return True
            
            #Skip node if node is in Skip rule [DEBUG]
            if node in skip_rule:
                print(f"Skipping {node}, REASON: Node in skip_rule")
                return True
            
            #Skip node in case predecessor routed to different path (If predecessor is a Router component)
            if pred_node != "__start__":
                pred_component = self.component_map[pred_node]
                #Check if Router predecessor decided to route to current node
                if isinstance(pred_component, Router) and node not in self.router_decisions[pred_node]: 
                    print(f"Skipping {node}, REASON: Predecessor routed to different node") 
                    return True

            return False

        #Starting execution of graph (create a new session for workflow and add to db) [TO DO]
        #A set of nodes to be skipped [For DEBUG]
        if skip_rule is None: skip_rule = {}
        
        #Retrieve graph execution order
        execution_order = [node for node in list(nx.topological_sort(self.graph))]

        #Set trigger as starting node
        self.graph.nodes[execution_order[0]]["is_starting_node"] = True

        #Maintain set of nodes that were visited
        visited = set()

        #If continuing previous invocation then do some setup
        previous_invoke_details = state["invocation_details"]
        if previous_invoke_details is not None:
            continue_from_node = previous_invoke_details["continue_from_node"]
            visited = set(previous_invoke_details["visited"])
            self.router_decisions = previous_invoke_details["router_decisions"]
            #state = previous_invoke_details["state"]
            #Setup state for continuing execution
            state["input"] = f"Input:{state['input']} System Response:{state['output']} Human Feedback: {human_feedback}"
            state["output"] = None
            state["human_feedback_required"] = False
            #Update execution order
            continue_from_node_index = execution_order.index(continue_from_node)
            execution_order = execution_order[continue_from_node_index:]
        # Reset router decisions on fresh invocation
        else:
            self.router_decisions = {}

        print(execution_order)
        
        for node in execution_order:
            #Getting predecessor node
            pred_node = _get_predecessor(node)

            #Check if node should be executed or skipped
            if _should_skip_node(node):
                continue

            #Extracting callable component from component map
            component = self.component_map[node]
            
            print(f"Visited node: {node} with component {component} from: {pred_node}")
            
            #Reset generation output
            state["generated_output"] = None
            
            #Update current state based on component logic
            
            #1) Inspect signature of component's call method
            call_sign = inspect.signature(component.__call__)
            call_parameters = call_sign.parameters

            #2) If signature expects user_info pass it else just state
            trace_metadata = {
            "instance_id": instance_id,
            "session_id": session_id
            }
            custom_trace_id = instance_id.replace('-', '')
            with self.langfuse.start_as_current_span(name=self.node_names.get(node, "Node"), metadata=trace_metadata, trace_context={"trace_id": session_id}) as span:
                if "user_info" in call_parameters:
                    state = await component(state, user_info)
                else:
                    state = await component(state)
                
            history = state["history"] if state["history"] is not None else []
            #If component is not Trigger or Input node then add its output to history
            if not (isinstance(component, Trigger) or isinstance(component, Input)):
                history.append({
                    "node_id":node,
                    "input": state["input"],
                    "output":state["output"],
                    "generated_output":state["generated_output"]
                })
            state["history"] = history
            
            #If node is a Router then store decision
            if isinstance(component, Router):
                #The output of Router is a path, we need to connect it with appropriate successor
                router_decision = state["output"]
                
                #Getting successor from the path-map
                self.router_decisions[node] = [self.router_paths[node][router_decision]]

            
            #If human feedback required then stop execution and return partial output
            if state["human_feedback_required"]:
                #Save invocation details
                invocation_details = {
                    "continue_from_node" : node,
                    "visited" : list(visited),
                    "router_decisions" : self.router_decisions,
                    #"state" : state
                }

                state["invocation_details"] = invocation_details
                return state

            #Set current node as visited
            visited.add(node)

            #Save details in db
            
            #1) Get workflow session data
            workflow_session_data = repository.get_workflow_session_by_id(session_id)
            if not workflow_session_data:
                raise LookupError(f"Workflow with session id {session_id} not found!")
            
            #2) Update the workflow session state and save in db
            workflow_session_data["state"] = state
            repository.update_workflow_session(workflow_session_data["_id"], session_class.from_dict(workflow_session_data))
            print(":::::SAVED NODE WISE EXECUTION")
        return state

class LanggraphStateGraph(Graph):
    """A langgraph based stategraph for use with agentic workflows."""
    def __init__(self):
        self.graph = None
        self.trigger_component = None
        self.component_map = {}
 
    def build_graph(self, workflow_schema):
        graph_builder = StateGraph(State)

        #Map to store conditional edges
        conditional_edge_map = {}

        #Extract nodes and edges from the graph
        nodes = workflow_schema.get("data", {}).get("nodes", {})
        edges = workflow_schema.get("data", {}).get("edges", {})

        #Populate the component_map
        for node in nodes:  
            #Extract node details
            node_id = node.get("id")
            node_name = node.get("name")
            node_type = node.get("type")
            node_config = node.get("config", None)
            
            #Create component from component factory
            component = ComponentFactory.create_component(node_type, node_config)
            self.component_map[node_id] = component
            
            #Add node to graph
            graph_builder.add_node(node_id, component)
            
            #Set trigger component if identified
            if isinstance(component, Trigger):
                if not self.trigger_component:
                    self.trigger_component = component
                    #Set trigger as entry point
                    graph_builder.set_entry_point(node_id)
                else: raise ValueError("Multiple trigger components detected! Exiting...")

        #Add edges
        for edge in edges:
            source = edge.get("source")
            destination = edge.get("destination")
            route = edge.get("route", None)

            #If source is router add edge in conditional_edge map
            if isinstance(self.component_map[source], Router):
                if route is None: raise ValueError("Route unspecified for router. Exiting...")
                conditional_edge_map.setdefault(source, {})[route] = destination
            #If not add a normal edge
            else:
                graph_builder.add_edge(source, destination)
        
        #Add conditional edges
        for source in conditional_edge_map:
            graph_builder.add_conditional_edges(source, lambda state: state["output"], conditional_edge_map.get(source, {}))

        #Compile the graph
        self.graph = graph_builder.compile()
    
    async def invoke(self, state, user_info=None)->State:
        state = await self.graph.ainvoke(state)
        return state