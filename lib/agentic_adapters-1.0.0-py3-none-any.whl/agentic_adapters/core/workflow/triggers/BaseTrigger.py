import threading
import asyncio
import time
import uuid

class BaseTrigger():
    def __init__(self, config, workflow_service_class, trigger_repository, user_info):
        self.trigger_id = config.get("id")
        self.trigger_name = config.get("name")
        self.trigger_type = config.get("type")
        self.workflow_map = config.get("workflow_map")
        self.workflow_service_class = workflow_service_class
        self.trigger_repository = trigger_repository
        self.user_info = user_info

    def execute_workflows(self):
        def run_workflow(id):
            session_id = str(uuid.uuid4()).replace('-','')
            print("Started thread with session_id", session_id)
            #Add trigger run details
            trigger_run_details = self.trigger_repository.get_trigger_runs_by_trigger_id(self.trigger_id)
            trigger_run_details["runs"].append({"workflow_id": id, "session_id":session_id})
            self.trigger_repository.update_trigger_runs(trigger_run_details["_id"], trigger_run_details)
            asyncio.run(self.workflow_service_class.execute_agent_workflow(id, self.user_info, {"trace_session_id":session_id}))
            print("finished thread with session id", session_id)
        for idx in self.workflow_map:
            threading.Thread(target=run_workflow, args=(int(idx),), daemon=True).start()
    
    def run(self, stop_event: threading.Event):
        while not stop_event.is_set():
            print(f"Trigger {self.trigger_id} says: Its morbin time")
            print(f"Trigger belongs to {self.user_info.get("username", "not found")}")
            self.execute_workflows()
            print("Triggered workflow!")
            time.sleep(100)
            
            #self.workflow_service_class.stop_trigger(self.trigger_id)
            