from .BaseTrigger import BaseTrigger
import threading
import os
import sys
import json
import time
from typing import Optional
from azure.servicebus import ServiceBusClient, ServiceBusMessage

class ServiceBusTrigger(BaseTrigger):
    def process_message(self, msg_body: str) -> None:
        """Handles the received message."""
        print("───────────────────────────────")
        try:
            data = json.loads(msg_body)
            print("Message JSON:")
            print(json.dumps(data, indent=2))
            return data
        except json.JSONDecodeError:
            print(f"Message Text: {msg_body}")
        print("───────────────────────────────\n")
    
    def run_listener(self, stop_event, poll_interval: int = 1, timeout: int = 240):
        """Continuously receives messages from the Service Bus queue."""
        start_time = time.time()
        
        servicebus_client = ServiceBusClient.from_connection_string(self.SB_CONN_STR)
        with servicebus_client:
            receiver = servicebus_client.get_queue_receiver(queue_name=self.SB_QUEUE_NAME)
            with receiver:
                while not stop_event.is_set():
                    elapsed_time = time.time() - start_time
                    if elapsed_time > timeout:
                        raise TimeoutError(f"No message received in {timeout} seconds.")
                    try:
                        messages = receiver.receive_messages(max_wait_time=poll_interval)
                        if not messages:
                            # No new message in this interval
                            continue
                        for msg in messages:
                            msg_body = str(msg)
                            data = self.process_message(msg_body)
                            receiver.complete_message(msg)
                            print(f"Completed message at {time.strftime('%H:%M:%S')}")
                            #Execute workflow
                            self.execute_workflows()
                    except Exception as e:
                        print(f"Error receiving message: {e}")
                        time.sleep(5)
    
    def __init__(self, config, workflow_service_class, trigger_repository, user_info):
        super().__init__(config, workflow_service_class, trigger_repository, user_info)
        # ─────────────────────────────────────────────
        # Path setup
        # ─────────────────────────────────────────────
        _THIS_DIR = os.path.dirname(__file__)
        _SRC_DIR = os.path.abspath(os.path.join(_THIS_DIR, ".."))
        if _SRC_DIR not in sys.path:
            sys.path.insert(0, _SRC_DIR)
        # ─────────────────────────────────────────────
        # Config & Env
        # ─────────────────────────────────────────────
        # Ensures it works behind Zscaler/VPN (HTTPS tunnel)
        os.environ["AZURE_SERVICEBUS_TRANSPORT_TYPE"] = "AmqpOverWebSockets"
        # Get connection settings
        self.SB_CONN_STR = "Endpoint=sb://asbnazone1dev02.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=UcZZZdbS2AGnIuInuMFvTB1ehDQ9EjKNU+ASbKO+0H8="
        self.SB_QUEUE_NAME = "servicenow-output"
        if not self.SB_CONN_STR or not self.SB_QUEUE_NAME:
            raise RuntimeError("SB_CONNECTION_STR or SB_QUEUE_NAME not set in .env or config")
        print(f"Connected Queue: {self.SB_QUEUE_NAME}")
    
    def run(self, stop_event: threading.Event):
        self.run_listener(stop_event)
