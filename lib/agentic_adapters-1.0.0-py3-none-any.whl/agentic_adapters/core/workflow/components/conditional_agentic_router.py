from agentic_framework.core.agent import Agent
from agentic_adapters.core.workflow.components.base.router import Router

class ConditionalAgenticRouter(Router):
    def __init__(self, config):
        self.condition = config.get("condition")
        self.model_config = config.get("model_config")
        agent_config = {
            "type": "googleadk",
            "agent": {
              "name": "RouterAgent",
              "prompts": [
                {
                  "message": "A router agent that performs routing based on given input",
                  "prompt_type": "description"
                },
                {
                  "message": "You will take user input and user condition. Evaluate based on given input whether the condition is satisfied or not. Based on that return a single word 'true' or 'false'. Return ONLY SINGLE WORD OUTPUT. If unable to determine what to do return 'false'",
                  "prompt_type": "instruction"
                }
              ]
            },
            "tools": [],
            "models": self.model_config,
            "callback_functions": None,
            "memory_type": "internal"
        }
        self.agent = Agent(agent_config)
    
    async def _route_to_path(self, data):
        #Set instruction for agent
        agent_instruction = f"""Given user input and user condition.
        Determine whether the condition is true or false. 
        Return single word true or false only.
        USER INPUT: {data["input"]}.
        CONDITION: {self.condition}."""
        
        #Call agent with given instructions
        agent_response = await self.agent.run(agent_instruction)

        #Set final output with trailing spaces and newlines/tab removed
        return agent_response.strip()
    
    async def __call__(self, state):
        """Routes the workflow based on router config"""

        #Modify state based on routing logic        
        state["output"] = await self._route_to_path(state)

        return state