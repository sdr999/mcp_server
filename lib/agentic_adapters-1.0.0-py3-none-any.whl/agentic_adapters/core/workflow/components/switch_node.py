from agentic_adapters.core.workflow.components.base.router import Router
import copy

class SwitchNode(Router):
    def __init__(self, config):
        #Need to evaluate this condition before saving
        self.conditions = config.get("conditions", [])
    
    async def _route_to_path(self, data):
        #Evaluate user defined condition on the json_data coming from previous node
        namespace = copy.deepcopy(data.get("json_output", {}))
        evaluation_logic = ""
        #Set up the evaluation logic template
        for idx, condition in enumerate(self.conditions):
            if idx == 0:
                evaluation_logic += f"if {condition}: output_data = 'condition{idx+1}'\n"
            else:
                evaluation_logic += f"elif {condition}: output_data = 'condition{idx+1}'\n"
            
        evaluation_logic += f"else: output_data = 'fallback_route'"
        
        try:
            exec(evaluation_logic, namespace)
        
        except Exception as e:
            #Default to false if exception occurs while evaluating the condition
            print("Exception occured while running the function:", e)
            return "false"
        
        #If giving condition evaluates to True then route to true else false
        evaluation = namespace["output_data"]
        return evaluation

    async def __call__(self, state):
        if state["output"] is not None: state["input"] = state["output"]
        state["output"] = await self._route_to_path(state)
        return state