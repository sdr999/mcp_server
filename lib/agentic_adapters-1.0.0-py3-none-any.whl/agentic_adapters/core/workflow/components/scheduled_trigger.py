from agentic_adapters.core.workflow.components.base.trigger import Trigger
from datetime import datetime, timedelta
 
class ScheduledTrigger(Trigger):
    def __init__(self, config):
        super().__init__(config)
        self.activation_time = int(config.get("activation_time"))
        self.output = config.get("output", "[NO INPUT]")
        self.target_time = None
        self.poll_interval = 1
    def should_execute(self):
        if not self.target_time:
            self.target_time = datetime.now() + timedelta(seconds=self.activation_time)
        elif self.target_time < datetime.now(): return True
        return False
   
    async def __call__(self, state=None):
        state["input"] = self.output
        state["output"] = self.output
        return state