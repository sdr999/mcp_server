from agentic_adapters.core.workflow.components.base.component import Component
from agentic_adapters.core.workflow.components.base.input import Input
import json
class ChatInput(Component, Input):
    def __init__(self, config):
        self.input = config.get("input", None)
    
    async def __call__(self, state):
        #Get context from output of previous node
        context = state["output"]
        json_output = state.get("json_output", {})
        input_string = f"Input:{self.input}, Context:{context}"
        #If input contains valid json string parse it as dict
        try:
            json_output = json_output | json.loads(self.input)
            state["json_output"] = json_output
        except Exception as e:
            print("Error parsing input as JSON", e) 
        
        state["input"] = self.input
        state["output"] = input_string
        return state