from agentic_adapters.core.workflow.components.base.component import Component
import json
import copy

class FunctionNode(Component):
    def __init__(self, config):
        self.func = config.get("source_code")

    async def __call__(self, state, user_info):
        authorization = user_info.get("authorization", "")
        # Extract JSON input for the function
        if state["output"] is not None:
            state["input"] = state["output"]

        input_data = state.get("json_output", {})
        input_data["auth_token"] = authorization
        # If json_output is missing but output is a JSON string, try to parse it
        if (not isinstance(input_data, dict)) or (input_data == {} and isinstance(state.get("output"), str)):
            try:
                parsed = json.loads(state.get("output", ""))
                if isinstance(parsed, dict):
                    input_data = parsed
            except Exception:
                # Keep input_data as-is if parsing fails
                pass

        if input_data is None:
            input_data = {}

        # Setup namespace for the function execution
        namespace = copy.deepcopy(input_data)
        # Also expose input under a well-known name for user functions
        # namespace["input_data"] = copy.deepcopy(input_data)

        # Run the user-provided function code
        exec(self.func, namespace)

        function_output = namespace.get("output_data", {})

        # Normalize output to a JSON-compatible dict
        if isinstance(function_output, str):
            try:
                function_output = json.loads(function_output)
            except Exception:
                function_output = {"result": function_output}
        elif not isinstance(function_output, dict):
            function_output = {"result": function_output}

        # Set the output in state object
        state["json_output"] = state.get("json_output", {}) | function_output
        try:
            state["output"] = json.dumps(function_output)
        except Exception:
            # Fallback to string conversion if something is not JSON-serializable
            state["output"] = str(function_output)

        return state