from agentic_adapters.core.workflow.components.base.component import Component

class DummyNode(Component):
    def __init__(self, config):
        self.output = config.get("output", "Placeholder Text!")

    async def __call__(self, state):
        state["output"] = self.output
        return state