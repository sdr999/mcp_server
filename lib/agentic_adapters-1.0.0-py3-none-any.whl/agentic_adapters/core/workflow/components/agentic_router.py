from agentic_framework.core.agent import Agent
from agentic_adapters.core.workflow.components.base.router import Router

class AgenticRouter(Router):
    """Agent based workflow router"""
    def __init__(self, config):
        agent_config = config.get("agent_config", {})
        self.routes = config.get("routes", ["fallback_route"])
        self.agent = Agent(agent_config)  

    async def _route_to_path(self, data, paths):
        #Define agent instruction
        agent_instruction = f"""You are a state router, Based on given input, return one of the {len(paths)} state(s). 
        Return only the state as single word and nothing else.
        Possible states: {paths}. IF AND ONLY IF output is WILDLY DIFFERENT from given paths return 'fallback_route'
        
        Input: {data['input']}"""

        #Call agent with given instructions
        agent_response = await self.agent.run(agent_instruction)

        #Set final output with trailing spaces and newlines/tab removed
        return agent_response["output"].strip()
        
    async def __call__(self, state):
        """Routes the workflow based on router config"""

        #Modify state based on routing logic        
        state["output"] = await self._route_to_path(state, self.routes)

        return state