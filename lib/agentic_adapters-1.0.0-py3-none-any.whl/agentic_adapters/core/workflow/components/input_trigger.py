from agentic_adapters.core.workflow.components.base.trigger import Trigger

class InputTrigger(Trigger):
    """An Input based trigger that runs workflow based on user input"""
    def __init__(self, config=None):
        super().__init__(config)
        self.output = config.get("input")
    
    def should_execute(self):
        return True
    
    async def __call__(self, state=None):
        state = {}
        state["input"] = self.output if self.output else input("Enter something\n")
        state["output"] = state["input"]
        return state