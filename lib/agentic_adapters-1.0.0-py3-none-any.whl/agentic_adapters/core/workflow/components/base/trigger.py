from agentic_adapters.core.workflow.components.base.component import Component
from abc import abstractmethod

class Trigger(Component):
    """Waits for some event trigger and executes workflow"""
    def __init__(self, config):
        self.poll_interval = config.get("poll_interval", 5)
    
    @abstractmethod
    def should_execute():
        """Decides if the trigger should execute or not"""
        pass

    @abstractmethod
    async def __call__(self, state=None):
        """Trigger execution logic for graph"""
        pass