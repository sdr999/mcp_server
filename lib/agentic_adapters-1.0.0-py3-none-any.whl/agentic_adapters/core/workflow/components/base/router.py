from agentic_adapters.core.workflow.components.base.component import Component
from abc import abstractmethod

class Router(Component):
    """Responsible for routing the workflow""" 
    @abstractmethod
    def _route_to_path(self, data: dict, paths: list)->str:
        pass

    @abstractmethod
    async def __call__(self, state):
        pass