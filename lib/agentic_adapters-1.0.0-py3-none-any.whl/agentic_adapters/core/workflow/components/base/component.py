from typing import TypedDict
from abc import ABC, abstractmethod

class State(TypedDict):
    input: str
    output: str

class Component(ABC):
    "A BaseComponent interface for implementing custom components for workflow"
    @abstractmethod
    async def __call__(self, state: State) -> State:
        pass