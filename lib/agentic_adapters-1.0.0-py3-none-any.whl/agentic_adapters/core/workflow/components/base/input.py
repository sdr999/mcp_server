from typing import TypedDict
from abc import ABC, abstractmethod

class Input(ABC):
    pass