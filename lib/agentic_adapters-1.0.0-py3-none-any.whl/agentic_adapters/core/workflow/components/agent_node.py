from agentic_adapters.core.workflow.components.base.component import Component
from agentic_framework.core.agent import Agent
import asyncio
import json
import base64
import mimetypes
from agentic_adapters.adapter_azure_file_share.azure_file_share import AzureFileAdapter
from agentic_framework.utils import global_variables
from agentic_adapters.utils.json_utils import extract_file_info
import os
import uuid
import openai
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class AgentNode(Component):
    """An Agent that reponds to user queries"""
    def __init__(self, config):
        print("Called Agent Init")
        self.env = global_variables.env
        agent_config = config.get("agent_config", {})
        self.agent_input = config.get("additional_properties", {}).get("config", {}).get("input", "[No input given]")
        self.model_details = agent_config.get("models")
        if self.model_details is not None:
            self.model_details = self.model_details[0].get("additional_properties", {})
        #Set memory type to internal
        agent_config["memory_type"] = "internal"
        self.agent = Agent(agent_config)
    
    async def __call__(self, state, user_info):
        #Get authorization token from user_info
        authorization = user_info.get("authorization", "")
        feedback_instruction = "\nIf you require further details from user or suspect an error. Prepend the string [feedback required] in same format to your response WITHOUT FAIL. If you are able to respond based on user's input, you feel user is satisfied/does not need further assistance or user specifically asks you for same then DO NOT PREPEND [feedback required]"
        
        #If previous node has an output use that as input to current node
        if state["output"] is not None: state["input"] = state["output"]
        state["input"] += f"\nInput Query: {self.agent_input}"
        print("HISTORY DEBUG:::::::\n", state.get("history"))
        #Extract context from history
        openai_api_key=self.model_details['AZURE_OPENAI_API_KEY']
        azure_endpoint=self.model_details['AZURE_OPENAI_ENDPOINT']
        openai_api_version=self.model_details['AZURE_OPENAI_API_VERSION']

        client = openai.AzureOpenAI(
            api_key=openai_api_key,
            api_version=openai_api_version,
            azure_endpoint=azure_endpoint
        )
        
        embedding_deployment_name = global_variables.env["EMBEDDING_DEPLOYMENT_NAME"]
        completions_deployment_name = global_variables.env["COMPLETIONS_DEPLOYMENT_NAME"]
        print("DEBUG:::::::", embedding_deployment_name, completions_deployment_name)

        # Function to get embedding from Azure OpenAI
        def get_embedding(text):
            response = client.embeddings.create(
                input=[text],
                model=embedding_deployment_name
            )
            return response.data[0].embedding

        # Function to retrieve top-k most similar documents
        def get_top_k_matches(query, documents, k=5):
            query_emb = np.array(get_embedding(query))
            doc_embeddings = [np.array(get_embedding(doc)) for doc in documents]
            similarities = cosine_similarity([query_emb], doc_embeddings)[0]
            top_k = similarities.argsort()[-k:][::-1]
            return [(documents[i], similarities[i]) for i in top_k]

        # Function to summarize text using Azure OpenAI Chat
        def summarize_text(text_block):
            system_prompt = "You are a helpful assistant that summarizes text."
            user_prompt = f"Summarize the following in a single paragraph, ensure unique points are covered:\n\n{text_block}"

            response = client.chat.completions.create(
                model=completions_deployment_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.5,
                max_tokens=300
            )
            return response.choices[0].message.content.strip()
        
        def requires_human_feedback(text_block):
            system_prompt = "You are an assistant that decides whether human feedback is needed for a given text."
            user_prompt = (
                "Analyze the following text and respond with only 'True' or 'False'. "
                "Return True IF you think human feedback is required for some clarification, questioning or error. Or human input is required to proceed"
                "Return False when the text is clear and complete, and no human review is needed.\n\n"
                f"{text_block}"
            )

            response = client.chat.completions.create(
                model=completions_deployment_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0,
                max_tokens=10
            )

            result = response.choices[0].message.content.strip().lower()
            print("DEBUG FEEDBACK RESULT::::::::::::", result)
            return "true" in result

        #Add historical content to vector store
        history_documents = []
        idx = 1
        for node_history in state["history"]:
            node_input = node_history.get("input", ""),
            node_output = node_history.get("output", "")
            history_documents.append(f"Input:{node_input}\nOutput:{node_output}\nMessage Order ID:{idx}")
            idx += 1


        if history_documents:
            top_matches = get_top_k_matches(state["input"], history_documents)
            # Combine top documents for summarization
            top_docs_combined = "\n\n".join([doc for doc, _ in top_matches])

            # Summarize
            summary = summarize_text(top_docs_combined)
            contextual_memory = f"\nContext from history:\n{summary}\n"
        else:
            contextual_memory = ""
        
        query = contextual_memory+state["input"]+feedback_instruction
        temp_file_path = None
        #File data logic

        #Step1 If state has file_data decode it
        if state['file_data'] is not None and state['file_data'] and state['file_data'].strip():

            # Step 1: Decode the file_data (base64 encoded string)

            file_data = state['file_data']

            # Check if the base64 string includes the MIME type (e.g., data:image/png;base64,...)

            if file_data.startswith("data:"):

                # Extract the MIME type from the base64 string

                header, base64_data = file_data.split(",", 1)

                mime_type = header.split(";")[0].split(":")[1]  # e.g., 'image/png'

                # Map MIME type to file extension

                file_extension = mimetypes.guess_extension(mime_type) or ".bin"  # Default to .bin if unknown

            else:

                # If the base64 string does not include MIME type metadata, assume it's a binary file

                base64_data = file_data

                file_extension = ".bin"

            # Decode the base64 string into binary data

            decoded_data = base64.b64decode(base64_data)

        #Step2 Save the decoded file data to temp path
            unique_id = uuid.uuid4().hex

            temp_file_name = f"{unique_id}{file_extension}"

            # temp_file_path = os.path.join(temp_folder_path, temp_file_name)

            temp_file_path =os.path.join("agentic_temp_storage",temp_file_name)
            
        #Step3 Set params to temp_path
            azure_file_adapter=AzureFileAdapter()

            azure_file_adapter.create_file(temp_file_path,decoded_data)

            print(f"Temporary file saved at: {temp_file_path}")


        #Flag to check if file was generated
        file_generated = False
        
        #Set params
        params = None
        if temp_file_path is not None:

            params={

                "file": temp_file_path

            }

        #Get agent response
        try:
            agentRes = await self.agent.run(query, params, mcp_authorization=authorization)
        except Exception as e:
            print(f"[ERROR] Exception during agent.run(): {str(e)}")
            import traceback
            traceback.print_exc()
            agentRes = f"An error occurred while processing your request: {str(e)}"

        # task = asyncio.create_task(self.agent.run(query, params, mcp_authorization=authorization))
        # agentRes = await task
        
        #Delete temp file if it was generated
        try:

                if temp_file_path:

                    azure_file_adapter=AzureFileAdapter()

                    azure_file_adapter.delete_file(temp_file_path)

        except Exception as e:
                print(f"[ERROR] Could not delete output file: {e}")
        
        #If file was generated handle it in state (Currently looks in azure file share)
        try:

            data = extract_file_info(agentRes)
            print(f"data ::::::::: {data}")

            output_file_path = data.get('file_path')

            print(f"output_file_path ::::: {output_file_path}") 

            encoded_file_data = None
            
            if output_file_path.split("/")[0]=="agentic_temp_storage":

                print(f"inside if :::::{output_file_path}")
                azure_file_adapter=AzureFileAdapter()
                encoded_file_data=azure_file_adapter.read_file_bytes(output_file_path)
                encoded_file_data= base64.b64encode(encoded_file_data).decode("utf-8")
                mime_type = mimetypes.guess_type(output_file_path)[0] or 'application/octet-stream'
                
                #If mime_type is image then file_generated is True
                if mime_type.startswith("image/") or mime_type == "application/pdf": 
                    file_generated = True
                    encoded_file_data = f"data:{mime_type};base64,{encoded_file_data}"  
                azure_file_adapter.delete_file(output_file_path)

            else:

                print(f"[WARN] Output file path does not exist: {output_file_path}")
 
            
 
            if encoded_file_data is not None:

                agentRes =  data.get('prompt')        

            state["output"] = agentRes
            state["file_data"] = encoded_file_data if encoded_file_data else None
            if file_generated: state["generated_output"] = state["file_data"]

        except Exception as e:

            print(f"agentRes :::::: {agentRes}")
            state["output"] = agentRes
        

        #If human feedback required in string then set flag
        if "feedback required" in agentRes.lower():
            state["human_feedback_required"] = True
            
        
        return state