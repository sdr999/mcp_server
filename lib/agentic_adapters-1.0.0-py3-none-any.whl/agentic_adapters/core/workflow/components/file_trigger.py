from agentic_adapters.core.workflow.components.base.trigger import Trigger
import os
from agentic_adapters.adapter_azure_file_share.azure_file_share import AzureFileAdapter

class FileTrigger(Trigger):
    """Checks if a file is added or removed in a directory"""
    def __init__(self, config):
        self.poll_interval = config.get("poll_interval", 5)
        self.watch_dir = config.get("watch_dir", None)
        self.history = None
        self.output_method = config.get("output_method", "predefined_output")
        self.output = config.get("output", "No input given")
    
    def should_execute(self):
        """Returns true if a file was added or removed in watch_dir"""
        fileshare_adapter = AzureFileAdapter()

        #Check if watch directory is provided
        if self.watch_dir:
            #If first run get snapshot
            snapshot = fileshare_adapter.list_files(self.watch_dir)
            if not self.history:
                self.history = snapshot
                return False
            
            #If snapshot exists then check if event was triggered
            if self.history != snapshot:
                self.history = snapshot
                return True
        
        return False
    
    async def __call__(self, state={}):
        #Get predefined output from config
        if self.output_method == "predefined_output":
            state["input"] = self.output
            state["output"] = self.output
        
        #Get input from user and relay it to graph
        else:
            print("Getting input from user")
            user_input = input("Enter something\n")
            state["input"] = user_input
            state["output"] = user_input
        
        return state