from agentic_adapters.core.workflow.components.base.component import Component
from agentic_adapters.core.workflow.components.base.input import Input
import json

class JsonInput(Component, Input):
    def __init__(self, config):
        self.input = config.get("input", None)
    
    async def __call__(self, state):
        #Get context from output of previous node
        context = state["output"]
        input_string = f"Input:{self.input}, Context:{context}"
        state["input"] = self.input
        state["output"] = input_string
        try:
            state["json_output"] = json.loads(self.input)
        except Exception as e:
            print("Could not parse json:", e)
        
        return state