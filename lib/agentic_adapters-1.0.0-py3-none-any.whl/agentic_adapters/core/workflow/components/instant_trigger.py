from agentic_adapters.core.workflow.components.base.trigger import Trigger
 
class InstantTrigger(Trigger):
    def __init__(self, config):
        super().__init__(config)
        self.output = config.get("output", "[NO INPUT GIVEN]")
   
    def should_execute(self):
        return True
   
    async def __call__(self, state={}):
        state["input"] = self.output
        state["output"] = state["input"]
        return state
   
 