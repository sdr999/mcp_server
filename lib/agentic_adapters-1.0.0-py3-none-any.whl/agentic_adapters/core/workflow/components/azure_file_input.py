from agentic_adapters.core.workflow.components.base.component import Component
from agentic_adapters.adapter_azure_file_share.azure_file_share import AzureFileAdapter
from agentic_adapters.core.workflow.components.base.input import Input
import base64
import mimetypes
from agentic_framework.utils import global_variables

class AzureFileInput(Component, Input):
    def __init__(self, config):
        self.env = global_variables.env
        self.input = config.get("input", None)
        self.file_dir = config.get("file_dir", None)
    
    async def __call__(self, state):
        #Get context from output of previous node
        context = state["output"]
        input_string = f"Input:{self.input}, Context:{context}"
        state["input"] = self.input
        state["output"] = input_string

        #If file_dir is given, try to read it and save it in file_data of state
        try:
            azure_file_adapter=AzureFileAdapter()
            encoded_file_data=azure_file_adapter.read_file_bytes(self.file_dir)
            encoded_file_data= base64.b64encode(encoded_file_data).decode("utf-8")
            mime_type = mimetypes.guess_type(self.file_dir)[0] or 'application/octet-stream'
            encoded_file_data = f"data:{mime_type};base64,{encoded_file_data}"
            if encoded_file_data: state["file_data"] = encoded_file_data
        
        except Exception as e:
            print("[WARNING] Cannot read contents of given file:", e)
            error_msg = f"Could not load file due to error!"
            state["output"] = error_msg

        return state