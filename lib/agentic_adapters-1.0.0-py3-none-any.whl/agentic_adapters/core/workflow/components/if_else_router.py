from agentic_adapters.core.workflow.components.base.router import Router
import copy

class IfElseRouter(Router):
    def __init__(self, config):
        #Need to evaluate this condition before saving
        self.condition = config.get("condition", "False")
    
    async def _route_to_path(self, data):
        #Evaluate user defined condition on the json_data coming from previous node
        namespace = copy.deepcopy(data.get("json_output", {}))

        #Set up the evaluation logic template
        evaluation_logic = f"""
output_data = {self.condition}
""" 
        try:
            exec(evaluation_logic, namespace)
        
        except Exception as e:
            #Default to false if exception occurs while evaluating the condition
            print("Exception occured while running the function:", e)
            return "false"
        
        #If giving condition evaluates to True then route to true else false
        evaluation = namespace["output_data"]
        if evaluation: return "true"
        return "false"

    async def __call__(self, state):
        if state["output"] is not None: state["input"] = state["output"]
        state["output"] = await self._route_to_path(state)
        return state