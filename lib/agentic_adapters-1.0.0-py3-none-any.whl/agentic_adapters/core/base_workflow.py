from abc import ABC, abstractmethod

class BaseWorkflow(ABC):
    
    @classmethod
    @abstractmethod
    def create_workflow():
        pass

    @abstractmethod
    def start_monitoring(self, state=None, human_feedback=None, session_id=None, session_class=None, repository=None, user_info=None):
        pass

    @abstractmethod
    def stop_monitoring():
        pass