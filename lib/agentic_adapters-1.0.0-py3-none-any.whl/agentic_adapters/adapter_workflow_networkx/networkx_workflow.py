from agentic_adapters.core.workflow.graph import Graph, NetworkXStateGraph
import asyncio
from agentic_adapters.core.base_workflow import BaseWorkflow

class NetworkXWorkflow(BaseWorkflow):
    """Responsible for workflow creation and management"""
    def __init__(self, workflow_schema: dict):
        self.graph = NetworkXWorkflow.create_workflow(workflow_schema)
        self.trigger_component = self.graph.trigger_component
        self.should_monitor = False
    
    @classmethod
    def create_workflow(cls, workflow_schema: dict)->Graph:
        """Creates a workflow and returns the workflow graph for Networkx"""
        
        graph = NetworkXStateGraph()
        graph.build_graph(workflow_schema)
        
        return graph
    
    async def start_monitoring(self, state=None, human_feedback=None, session_id=None, session_class=None, repository=None, user_info=None, json_input=None,instance_id=None):
        """Start monitoring for event(s) that should trigger workflow execution"""
        
        if not self.trigger_component:
            raise ValueError("No trigger component identified in workflow!")
        
        self.should_monitor = True
        print("[DEBUG] Starting to monitor for trigger event(s)....")
        
        #If continuing a previous invokation do some setup
        if state is not None:
            previous_invoke_details = state["invocation_details"]

        while self.should_monitor:
            #Poll for event (Skip polling if continuing previous invokation)
            if self.trigger_component.should_execute() or previous_invoke_details is not None:
                print("Event Triggered!")

                #Run workflow based on trigger output
                if state is None:
                    state={
                        "input":None,
                        "output":None,
                        "history":None,
                        "file_data":None,
                        "json_output": json_input,
                        "generated_output":None,
                        "human_feedback_required":False,
                        "invocation_details":None
                    }
                
                result = await self.graph.invoke(state=state, human_feedback=human_feedback, session_id=session_id, session_class=session_class, repository=repository, user_info=user_info,instance_id=instance_id)
                print(result)
                self.stop_monitoring()
                return result

            print("Event not triggered!")
            #Wait for polling interval
            for _ in range(self.trigger_component.poll_interval):
                if not self.should_monitor:
                    break
                await asyncio.sleep(1)


    
    def stop_monitoring(self):
        """Stop monitoring for trigger event(s)"""
        self.should_monitor = False
        print("Stopping trigger event(s) monitoring....")