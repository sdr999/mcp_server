import os
from jinja2 import Environment, FileSystemLoader
from agentic_adapters.core.base_tool_generator import BaseToolGenerator


class LangGraphToolGenerator(BaseToolGenerator):
    def __init__(self):
        print("ToolGenerator Init")
        base_dir = os.path.dirname(os.path.abspath(__file__))
        template_dir = os.path.join(base_dir, "config")    
        self.tools_dir = os.path.join(base_dir, "tools")    
        self.template_env = Environment(loader=FileSystemLoader(template_dir))

    def render_template(self, tool_config: dict):
        template = self.template_env.get_template("tool-template.jinja")
        print(f'tool_config {tool_config}')
        data = {
            "source_code": tool_config['source_code']
        }
        return template.render(tool_config)
    
    def save_tool(self, tool_config: dict, tool_content: str):
        print("Inside save_tools")                
        #file_name = f'{tool_config['name']}.py'
        file_name = tool_config['name'] + ".py"        
        tool_path = os.path.join(self.tools_dir, file_name)    
        with open(tool_path, 'w') as f:
            f.write(tool_content)
 
    def generate(self, tool_config: dict):
        content  = self.render_template(tool_config)
        self.save_tool(tool_config, content)
