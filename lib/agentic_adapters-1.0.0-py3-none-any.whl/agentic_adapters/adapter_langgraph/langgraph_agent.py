from agentic_adapters.core.base_agent import BaseAgent
from langchain_community.agent_toolkits.load_tools import load_tools
from langchain_core.tools import Tool
from langchain.callbacks.manager import CallbackManagerForToolRun
from langchain.tools.base import BaseTool
from langgraph.prebuilt.tool_node import ToolNode
from langgraph.graph.message import add_messages
from langchain.agents import create_openai_functions_agent
from langchain_community.chat_models import AzureChatOpenAI
from uuid import uuid4
from langchain_core.messages import HumanMessage
from langchain_core.runnables import Runnable
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents import create_openai_functions_agent, AgentExecutor, tool
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_mcp_adapters.client import load_mcp_tools
from langgraph.graph import StateGraph, END
from langchain.callbacks.base import BaseCallbackHandler
import os
import subprocess
import sys
from langchain import hub
import importlib
import asyncio
import json
from typing import Any, Dict, List,TypedDict, Optional,cast
from pydantic import BaseModel, Field
from contextlib import AsyncExitStack
# MCP Client imports
from mcp.client.session import ClientSession
from mcp.client.sse import sse_client
import jwt
import time
import threading
from agentic_framework.utils import global_variables
from langchain_community.chat_message_histories import MongoDBChatMessageHistory
# import nest_asyncio
# nest_asyncio.apply()
import openlit
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler
from pathlib import Path
from dotenv import load_dotenv
from opentelemetry.propagate import inject

cp=Path(__file__).resolve().parent.parent/"config"/ "config.properties"
load_dotenv(dotenv_path=cp)
class MCPAgentManager:
    def __init__(self):
        self.sessions: Dict[str, ClientSession] = {}
        self.available_tools =[]
        self.exit_stack = AsyncExitStack()
        self._contexts = {}  # To store context managers per server

    @classmethod
    async def create(cls, mcp_server_urls: Optional[List[str]] = None, mcp_auth= None) -> Optional["MCPAgentManager"]:
        manager = cls()
        headers={
                    "Authorization":mcp_auth
                }
        # Load from environment if not provided
        if mcp_server_urls is None:
            mcp_server_urls = [global_variables.env["MCP_URL"]]

        for url in mcp_server_urls:
            try:
                streams_context = sse_client(url=url,headers=headers)
                streams = await streams_context.__aenter__()

                session_context = ClientSession(*streams)
                session: ClientSession = await session_context.__aenter__()
                print("initializing")
                await session.initialize()

                tools = await load_mcp_tools(session=session)

                manager.sessions[url] = session
                manager.available_tools.extend(tools)
                manager._contexts[url] = {
                    "streams": streams_context,
                    "session": session_context
                }

                print(f" Connected to MCP server: {url}")
                print(f"    Tools available: {tools}")
            except Exception as e:
                print(f" Failed to connect to MCP server at {url}: {e}")
        print("\n\n\n\nAvailable tools :: :: :: \n",manager.available_tools)
        if not manager.sessions:
            print("❌ No MCP servers could be connected.")
            return None

        return manager

    async def close(self):
        for ctx in self._contexts.values():
            await ctx["session"].__aexit__(None, None, None)
            await ctx["streams"].__aexit__(None, None, None)


        
    async def cleanup(self):
        """Properly clean up the session and streams"""
        if self._session_context:
            await self._session_context.__aexit__(None, None, None)
        if self._streams_context:
            await self._streams_context.__aexit__(None, None, None)
    
    def filter_tools(self,tool_names : List )-> List[Tool]:
        print("############################################### filter tools")
        filtered_tools = []
        print("tools names", tool_names)
        print("Available tools:: :: :: ::",self.available_tools)
        for tool_name in tool_names:
            print("Inside for ")
            tool = next((t for t in self.available_tools if t.name == tool_name), None)
                # Real MCP tool
            if tool:
                filtered_tools.append(tool)


        print(f"filtered_tools ::::: {filtered_tools}")
        return filtered_tools
   


class SimpleMemoryStore:
    def __init__(self):
        self._store = {}

    def get_memory(self, session_id: str) -> InMemoryChatMessageHistory:
        if session_id not in self._store:
            self._store[session_id] = InMemoryChatMessageHistory()
        return self._store[session_id]

    def add_memory(self, session_id: str, message):
        self._store.setdefault(session_id, []).append(message)

memory_store = SimpleMemoryStore()

class CustomCallbackHandler(BaseCallbackHandler):
    _llm_end_func:str = None
    _llm_start_func:str = None
    _tool_end_func:str = None
    _tool_start_func:str = None
    model_function = None
    tools_function = None

    def __init__(self,functions:Any=None):
        super().__init__()
        if functions is not None:
            self.model_function=functions["model"]
            self.tools_function=functions["tools"]
            self._llm_start_func=self.model_function["before"]
            self._llm_end_func=self.model_function["after"]
            self._before_model_func_param=self.model_function["before_params"] if self.model_function["before_params"] else None
            self._after_model_func_param=self.model_function["after_params"] if self.model_function["after_params"] else None
            
    # Tool Start
    def on_tool_start(self, serialized, input_str, *, run_id=None, **kwargs):
        try:
            if self.tools_function is not None:
                tool_name=serialized.get("name","Tool")
                params={
                    "TOOL_NAME":tool_name,
                    "TOOL_RESPONSE":None
                }
                self._tool_start_func=self.tools_function[tool_name]["before"]
                params= params | self.tools_function[tool_name]["before_params"]
                if self._tool_start_func is not None:
                    exec(self._tool_start_func,{"self": self},params)
        except Exception as e:
            
            print("\n:: :: :: Callback execution failed :: :: ::",e)
    # Tool End
    def on_tool_end(self,output, *, run_id=None, **kwargs):
        try:
            if self.tools_function is not None:
                tool_name=kwargs.get("name","Tool")
                params={
                    "TOOL_NAME":tool_name,
                    "TOOL_RESPONSE":output
                }
                self._tool_end_func=self.tools_function[tool_name]["after"]
                params=params | self.tools_function[tool_name]["after_params"]
                if self._tool_end_func is not None:
                    exec(self._tool_end_func,{"self": self},params)
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
    # LLM Start
    def on_llm_start(self, serialized, prompts, *, run_id=None, **kwargs):
        try:
            if self.model_function is not None:
                if self._llm_start_func is not None:
                    exec(self._llm_start_func,{"self": self},self._before_model_func_param)
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")
 
    # LLM End
    def on_llm_end(self, response, *, run_id=None, **kwargs):
        try:
            if self.model_function is not None:
                if self._llm_end_func is not None:
                    exec(self._llm_end_func,{"self": self},self._after_model_func_param)
        except:
            print("\n:: :: :: Callback execution failed :: :: ::\n")


class LangGraphAgent(BaseAgent):
    def __init__(self,config):
        self.config = config
        self.langfuse_public_key=global_variables.env['LANGFUSE_PUBLIC_KEY']
        self.langfuse_secret_key=global_variables.env['LANGFUSE_SECRET_KEY']
        self.langfuse_host=global_variables.env['LANGFUSE_HOST']
        self.langfuse = Langfuse(
            secret_key=self.langfuse_secret_key,
            public_key=self.langfuse_public_key,
            host=self.langfuse_host
           )
        self.langfuse_handler = CallbackHandler(update_trace=True)
        # openlit.init(tracer=self.langfuse._otel_tracer,event_logger=True, application_name="hello htere")
        print("##############################################################")
        print(self.config)
        print("##############################################################")
        self.db_url=f'mongodb://{global_variables.env["MONGO_DB_HOST"]}:{global_variables.env["MONGO_DB_PORT"]}/' 
        self.db_name=global_variables.env["MONGO_DB_NAME"]
        # self.session_id = "1234"
        #Get memory type
        self.memory_type = self.config.get("memory_type", "external")
        if self.memory_type != "external":
            self.session_id = str(uuid4())
        else:
            self.session_id = self.config.get('instance_id') or self.config.get("agent").get("name")
        
        print('session id:',self.session_id)
        # self.session_id = str(uuid4())
        # Store tools and tool executor
        functions=self.config["callback_functions"]
        print("functions:: :: ::",functions)
        self.custom_callback_handler=CustomCallbackHandler(functions)
        self.mcp_servers=self.config["mcp_servers"]#["http://localhost:8000/sse"]
        self.mcp_auth=self.config["mcp_authorization"]
        if "connector_description" in self.config:
            self.connector_config=self.config["connector_description"]
        else:
            self.connector_config=None
        self.tools = []
        self.tool_node = None
        self.mcp_approach=3
        self.traj_eval = False
        match self.mcp_approach:
            case 1:
                print("Getting tools from generated MCP server (Approach 1)")
            case 2:
                print("Getting all tools from MCP server (Approach 2)")
                self.tools = asyncio.run(self.load_all_tools())
            case _:
                print("Getting select tools from MCP server (Approach 3)")
                self.tools = asyncio.run(self.connect_mcp())
                #self.tools = run_async_safely(self.connect_mcp())
        
        self.tool_node =ToolNode(self.tools)
        print("Runnable with tools: ", self.tools)

        self.install_package()

        # Set up Azure OpenAI LLM
        self.llm = self.load_llm()
        self.prompts=self.load_prompts()
        # Create the ReAct agent
        self.agent_executor = AgentExecutor(
            agent=create_openai_functions_agent(self.llm, self.tools, self.prompts),
            tools=self.tools,
            verbose=True,
            handle_parsing_errors=True,
            return_intermediate_steps=True
        )
        # In-memory state store: {session_id: List[message]}
        

        # Compile the LangGraph agent once
        self.graph = self._build_graph()

        #this is to pip install library


    def set_connector_description(self,toolsets):
        if self.connector_config["REST"]:
            for tool in toolsets:
                if getattr(tool, 'name', None) == "rest_connector":
                    tool.description = self.connector_config["REST"]
        return toolsets
    def install_package(self, import_name=None):
        # print(f"inside install_package:: {self.config}")
        tools = self.config['tools']
        #package_names = ""
        for tool in tools:
            if tool['package_names'] is not None:
                package_names = tool['package_names']   
                print(f"package_name :::: {package_names}")
                for package_name in package_names:
                    print(f"inside for package_name :::: {package_name}")                    
                    try:
                        importlib.import_module(package_name)
                        print(f"'{import_name}' is already installed.")
                    except ImportError:
                        print(f"'{import_name}' not found. Installing '{package_name}'...")
                        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])     

    def load_prompts(self)-> Any:
        prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful AI assistant."),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
        MessagesPlaceholder("agent_scratchpad"),
        ])
        return prompt
    
    class AgentState(TypedDict):
        input: str
        chat_history: List[Any] = []
        output: str = ""

    def _build_graph(self) -> RunnableWithMessageHistory:
        async def agent_node(state: Dict) -> Dict:
            response = await self.agent_executor.ainvoke({
                "input": state["input"],
                "chat_history": state["chat_history"]
            })
            print("response :: :: :: ::",response)
            if self.traj_eval :
                return response
            return {
                "output": response['output']
            }


        workflow = StateGraph(self.AgentState)
        workflow.add_node("agent", agent_node)
        workflow.set_entry_point("agent")
        workflow.add_edge("agent", END)

        compiled_graph = workflow.compile()




        def get_message_history(session_id: str)-> MongoDBChatMessageHistory:
            return MongoDBChatMessageHistory(
                session_id=session_id,
                connection_string=self.db_url,
                database_name=self.db_name,
                collection_name="chat_history"
            )

        return RunnableWithMessageHistory(
            compiled_graph,
            get_message_history,
            input_messages_key="input",
            history_messages_key="chat_history"
        )

    def load_llm(self) -> Any:
        
        print(f"inside load_llm:: {self.config['models']}")
        model_additional_properties = None
        for model in self.config['models']:
            model_additional_properties = model['additional_properties']  

        print(f"model additional_properties :::: {model_additional_properties}")   
        if model_additional_properties is not None:
            azure_chat_openAI = AzureChatOpenAI(
                    deployment_name=model_additional_properties['AZURE_OPENAI_DEPLOYMENT_NAME'],
                    openai_api_key=model_additional_properties['AZURE_OPENAI_API_KEY'],
                    azure_endpoint=model_additional_properties['AZURE_OPENAI_ENDPOINT'],
                    openai_api_version=model_additional_properties['AZURE_OPENAI_API_VERSION'],
                    temperature=int(model_additional_properties['temperature'])
                )
            return azure_chat_openAI

    async def load_all_tools(self):
            
            try:
                manager = await MCPAgentManager.create()
                self.manager=manager
                print("******************MCP CONNECTED**************")
            except Exception as e:
                print("******************MCP CONNECTing failed**************")
            try:
                tool = manager.available_tools
                print("****************** ALL MCP Tools LOADED**************")
                print(tools)
            except Exception as e:
                print(f"Agent 1 Error: {e}")
                print("******************MCP Tools Loading failed**************")
                tools=None
            print(f"\n\n\n\nloaded tools from mcp{tools}\n\n\n\n")
            return tools
    
    def get_tools(self) -> list:
        # print(f"inside get_tools:: {self.config}")
        tool_names=None
        tools_name = []
        tools = self.config['tools']
        if tools is not None:
            for tool in tools:
                tools_name.append(tool['name'])   
        print(f"tools_name ::: {tools_name}")                 
        return tools_name

    async def connect_mcp(self):
            tools=[]
            try:
                manager = await MCPAgentManager.create(mcp_server_urls=self.mcp_servers,mcp_auth= self.mcp_auth)
                self.manager=manager
                print("******************MCP CONNECTED**************")
            except Exception as e:
                print("******************MCP CONNECTing failed**************")
            
            try:
                tool = self.get_tools()
                tools=self.manager.filter_tools(tool)
                if self.connector_config:
                    tools=self.set_connector_description(toolsets=tools)
                print("******************MCP Tools After filter**************")
                print(tools)
            except Exception as e:
                print(f"Agent 1 Error: {e}")
                
            return tools

    #  execute_agent_node now supports cancel_event 
    async def execute_agent_node(self, input, cancel_event: asyncio.Event = None,trace_session_id=None):
        # Launch graph execution as a task
        trace_metadata = {
            "agent_name": self.config.get('agent_name'),
            "instance_id": self.config.get("instance_id"),
            }
        custom_trace_id = self.config.get('instance_id').replace('-', '') if self.config.get('instance_id') else self.config.get('agent_name')
        with self.langfuse.start_as_current_span(name=trace_session_id, metadata=trace_metadata, trace_context={"trace_id": trace_session_id if trace_session_id else custom_trace_id}) as span:
        
            graph_task = asyncio.create_task(
                self.graph.ainvoke(
                    {"input": input},
                    config={
                        "configurable": {"session_id": self.session_id},
                        #"metadata":{"agent_name" :self.config["agent"].get("name"), "instance_id":self.config.get("instance_id")},
                        "callbacks": [self.custom_callback_handler, self.langfuse_handler],#,
                        "run_name" : self.config.get("instance_id")
                        # "run_name":self.config["agent"].get("name"),
                        # "run_id":self.config.get("instance_id")
                    }
                )
            )

        try:
            # Check periodically for cancellation
            while not graph_task.done():
                await asyncio.sleep(0.2)
                if cancel_event and cancel_event.is_set():
                    graph_task.cancel()
                    print("[CANCEL] LangGraph agent execution cancelled.")
                    raise asyncio.CancelledError("LangGraph execution was cancelled.")


            result = await graph_task

            print("###########################################")
            print(result["output"])

            if self.traj_eval:
                return self.get_langgraph_trajectory(result)

            return result["output"]

        except asyncio.CancelledError as e:
            return {"status": "cancelled", "message": "agent terminated"}
        except Exception as e:
            print(f"[ERROR] LangGraph agent execution failed: {e}")
            return {"status": "failure", "message": str(e)}


    # 2. Pass cancel_event from run 
    async def run(self, input: str, params=None, traj_eval=False, cancel_event: asyncio.Event = None,mcp_authorization=None,trace_session_id=None) -> Any:
        self.traj_eval = traj_eval
        self.mcp_auth=mcp_authorization
        print(f"\n\n\n input in run ::: {input} \n\n\n")
        print(f"\n\n\n params in run ::: {params} \n\n\n")

        fixer = """Use proper markdown formatting strictly for display content. Do not apply any markdown formatting (e.g., backticks, asterisks) to file paths, dictionary keys, or values.

    When using a retrieval tool to display data:
    - Format the data in markdown for readability, but exclude file paths from markdown formatting.

    For function calls:
    - Include the function name if the function requires it.

    For image generation:
    - Return only a raw JSON object with no additional text, explanation, or formatting.

    For outputs that include file paths:
    - Ensure there is only one forward slash between directories.
    - Return a dictionary in the following format:

        {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt,
            "response": Markdown-based agent response summary
        }

    If the tool returns only:
        {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt
        }

    Then automatically append the "response" key with a markdown-formatted agent response summary, resulting in the four-key dictionary structure shown above.

    Do not wrap the dictionary output in markdown formatting. Do not include any extra text or symbols around the JSON.
    """
        input += fixer
        if params is not None:
            if params.get("file", ""):
                input += "file path :" + params["file"]
            if params.get("tools_id", ""):
                input += "tools_id :" + params["tools_id"]

        print("DEBUG", input)

        return await self.execute_agent_node(input, cancel_event=cancel_event,trace_session_id=trace_session_id)

    
    def get_langgraph_trajectory(
        self,
        output : Any
    ) -> List[Dict[str, Any]]:
        
        print(f"\n\n Langgraph output : {output}\n\n")
        
        messages = []

        user_input = output.get('input')
        intermediate_steps = output.get('intermediate_steps')
        final_response = output.get('output')

        # Step 1: User input
        messages.append({"role": "user", "content": user_input})

        # Step 2: Iterate through intermediate steps
        if intermediate_steps: 
            for action, observation in intermediate_steps:
                # Extract function name from tool (could sanitize if needed)
                function_name = action.tool.strip()

                # Format tool_input; assume input can be interpreted as arguments
                try:
                    # Try parsing tool_input as a dictionary
                    arguments = json.loads(action.tool_input)
                except Exception:
                    # If not JSON, wrap as {"input": ...}
                    arguments = {"input": action.tool_input}

                # Tool call step by assistant
                messages.append(
                    {
                        "role": "assistant",
                        "content": "",
                        "tool_calls": [
                            {
                                "function": {
                                    "name": function_name,
                                    "arguments": json.dumps(arguments),
                                }
                            }
                        ],
                    }
                )

                # Tool response
                messages.append({"role": "tool", "content": observation})

        # Step 3: Final assistant message
        messages.append({"role": "assistant", "content": final_response})

        return messages