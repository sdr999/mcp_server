from langgraph.graph import StateGraph, END
from agent_factory import Factory
#from langgraph_agent import custom_agent_node
from adapter_langgraph.langgraph_agent import AgentState
from adapter_langgraph.langgraph_agent import LangchainAgent




# Example usage
if __name__ == "__main__":
    
    config={
        "system_prompt":[
            "You are a assitant, who search Stack Exchange for information"
        ],
        "tool_names":"wikipedia",
        #"tool_name":"stackexchange",
        "package_name":"wikipedia"
        #"package_name": "google-search-results"
    }
    obj1 = Factory.create_instance("adapter_langgraph.langgraph_agent.LangchainAgent", config)
    # print("\n\n\n")
    # print(type(obj1))
    # print(dir(obj1))
    # print("\n\n\n")
    response = obj1.run({"input": "Who is the CEO of Tesla?"}, config)
    #response = obj1.run({"input": "What is Google's stock?"}, config)
    print(response)
    # print(response['output'])
    # print(response['output']['output'])