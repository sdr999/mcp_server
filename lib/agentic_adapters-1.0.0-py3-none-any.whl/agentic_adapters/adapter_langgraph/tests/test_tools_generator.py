import os, sys
from pathlib import Path
import json
sys.path.append(str(Path(__file__).parent.parent.parent))

from agentic_adapters.adapter_langgraph.core.langgraph_tool_generator import LangGraphToolGenerator


def test_generate_tool():
    print("test_generate_tool")
    
    test_dir = os.path.dirname(os.path.abspath(__file__))
    data_file_path = os.path.join(test_dir, "data", "test-tool-data.json")  
    with open(data_file_path) as f:
        data = json.load(f)
    tool_generator = LangGraphToolGenerator()
    tool_generator.generate(data)


if __name__ == "__main__":
    test_generate_tool()
 