import json
import re

def extract_file_info(agent_res: str):
    """
    Extract file_name, file_path, and optional prompt from agent response.
    Handles JSON, messy text, inconsistent keys, and unstructured key-value pairs.
    """
    def normalize_keys(data: dict):
        return {
            key.strip().lower().replace(" ", "_"): value
            for key, value in data.items()
        }

    def validate_file_info(data: dict):
        if "file_name" in data and "file_path" in data:
            return {
                "file_name": data["file_name"],
                "file_path": data["file_path"],
                "prompt": data.get("prompt")
            }
        return None
    # 1. Try JSON inside code block
    agent_res_copy=agent_res
    try:
        file_name = re.search(r'\*\*File Name:\*\* `(.+?)`', agent_res_copy).group(1)
        file_path = re.search(r'\*\*File Path:\*\* `(.+?)`', agent_res_copy).group(1)
        prompt = re.search(r'\*\*Prompt:\*\* (.+)', agent_res_copy).group(1)
 
        # Remove backticks from prompt if any
        prompt = re.sub(r'`', '', prompt)
 
        # Construct dictionary
        result = {
            "file_name": file_name,
            "file_path": file_path,
            "prompt": prompt.strip()
        }
 
        # Convert to JSON (optional print)
        json_result = json.dumps(result, indent=4)
        return(json_result)
    except:
        pass
    json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', agent_res, re.DOTALL)
    if json_match:
        try:
            raw_data = json.loads(json_match.group(1))
            if isinstance(raw_data,str):
                raw_data=json.loads(raw_data)
            return validate_file_info(normalize_keys(raw_data))
        except json.JSONDecodeError:
            pass
    agent_res=agent_res.strip("`").strip("json").strip()
    # 2. Try plain JSON
    try:
        raw_data = json.loads(agent_res)
        return validate_file_info(normalize_keys(raw_data))
    except json.JSONDecodeError:
        pass

    # 3. Try key-value pairs (colon separated, no JSON)
    kv_pairs = dict(
        (k.strip().lower().replace(" ", "_"), v.strip())
        for k, v in re.findall(r'(\bfile[_ ]?name|file[_ ]?path|prompt)\s*[:=]\s*([^\s"]+)', agent_res, re.IGNORECASE)
    )
    if "file_name" in kv_pairs and "file_path" in kv_pairs:
        return {
            "file_name": kv_pairs["file_name"],
            "file_path": kv_pairs["file_path"],
            "prompt": kv_pairs.get("prompt")
        }

    # 4. Try compact pattern like filename=report.pdf filepath=... with no quotes
    kv_pairs = dict(
        (k.strip().lower(), v.strip())
        for k, v in re.findall(r'(filename|filepath|file_name|file_path|prompt)[\s:=]+([^\s"]+)', agent_res, re.IGNORECASE)
    )
    # Normalize
    kv_pairs = {
        k.replace("filename", "file_name").replace("filepath", "file_path"): v
        for k, v in kv_pairs.items()
    }

    if "file_name" in kv_pairs and "file_path" in kv_pairs:
        return {
            "file_name": kv_pairs["file_name"],
            "file_path": kv_pairs["file_path"],
            "prompt": kv_pairs.get("prompt")
        }

    return None

