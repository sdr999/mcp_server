from agentic_adapters.core.workflow.graph import Graph, LanggraphStateGraph
import asyncio
from agentic_adapters.core.base_workflow import BaseWorkflow

class LanggraphWorkflow(BaseWorkflow):
    """Responsible for workflow creation and management"""
    def __init__(self, workflow_schema: dict):
        self.graph = LanggraphWorkflow.create_workflow(workflow_schema)
        self.trigger_component = self.graph.trigger_component
        self.should_monitor = False
    
    @classmethod
    def create_workflow(cls, workflow_schema: dict)->Graph:
        """Creates a workflow and returns the workflow graph for Langgraph"""
        
        graph = LanggraphStateGraph()
        graph.build_graph(workflow_schema)
        
        return graph
    
    async def start_monitoring(self, state=None, human_feedback=None, session_id=None, session_class=None, repository=None, user_info=None):
        """Start monitoring for event(s) that should trigger workflow execution"""
        
        if not self.trigger_component:
            raise ValueError("No trigger component identified in workflow!")
        
        self.should_monitor = True
        print("Starting to monitor for trigger event(s)....")
        while self.should_monitor:
            #Poll for event
            if self.trigger_component.should_execute():
                print("Event Triggered!")

                #Run workflow based on trigger output
                result = await self.graph.invoke(state={}, user_info=user_info) #No state is passed because its handled by trigger
                print(result)
                self.stop_monitoring()
                return result

            print("Event not triggered!")
            #Wait for polling interval
            for _ in range(self.trigger_component.poll_interval):
                if not self.should_monitor:
                    break
                await asyncio.sleep(1)


    
    def stop_monitoring(self):
        """Stop monitoring for trigger event(s)"""
        self.should_monitor = False
        print("Stopping trigger event(s) monitoring....")